# AI Interview Coach (OpenAI GPT-4o, Whisper & TTS Suite)

A complete, highly polished full-stack simulated mock interview application designed to prepare tech and professional candidates for high-pressure board panels. Built natively using **React.js + Tailwind CSS** on the frontend, with a **Node.js Express + SQLite (JSON File-backed)** backend, using **OpenAI APIs only**.

## Project Architecture & Directory Layout

```
.
├── .data/                  # Persistent SQLite JSON records database folder
│   └── db.json             # Structured JSON-file schema database
├── src/
│   ├── components/
│   │   ├── AdminPanel.tsx  # Global site usage analytics & metrics
│   │   ├── AIInterviewer.tsx # Real-time mock conversation & Whisper/TTS room
│   │   ├── Auth.tsx        # Modern login & sign-up forms
│   │   ├── CodingRound.tsx # Whiteboard workspace & complexity analyzers
│   │   ├── Dashboard.tsx   # Hub workspace and historical mock logs
│   │   ├── InterviewSetup.tsx # Configure roles, seniority, and document grounding
│   │   ├── LandingPage.tsx # SaaS presentation visual portal
│   │   ├── Navbar.tsx      # Responsive header with theme controller
│   │   ├── ReportView.tsx  # Detailed final scores and Hiring Decision report
│   │   ├── Settings.tsx    # Secure client token save & profile editing
│   │   └── ThemeContext.tsx # CSS light/dark global contexts
│   ├── App.tsx             # Main routing hub and core session manager
│   ├── db.ts               # File-backed persistence database queries wrapper
│   ├── index.css           # Global typography styles & transitions
│   ├── main.tsx            # React application mounting entry point
│   ├── openai.ts           # OpenAI GPT-4o, Whisper, and TTS calling layers
│   └── types.ts            # Central data type interfaces & models definitions
├── .env.example            # Environment configurations blueprint
├── index.html              # Document entry point
├── package.json            # NPM dependencies & Express fullstack scripts
├── server.ts               # Express Backend server controller and middleware routes
├── tsconfig.json           # TS rules configuration
└── vite.config.ts          # Vite asset configurations
```

---

## 1. Database Schema Definitions

Our schema is designed for full relational mapping representing user configurations, interview records, dialogue histories, and parsed resume documents:

*   **User Schema (`User`):**
    *   `id`: `string` (Unique auto-increment hash)
    *   `name`: `string` (Candidate display name)
    *   `email`: `string` (Registered authentication address)
    *   `passwordHash`: `string` (Secure match verification string)
    *   `createdAt`: `string` (Date ISO string)
    *   `isAdmin`: `boolean` (Privileged statistics monitor)

*   **Interview Session Schema (`Interview`):**
    *   `id`: `string` (Unique mock identifier)
    *   `userId`: `string` (Relates to candidate user)
    *   `jobRole`: `string` (Target role: e.g. Software Engineer, AI Engineer)
    *   `experienceLevel`: `ExperienceLevel` (`Fresher` | `Junior` | `Mid-Level` | `Senior`)
    *   `interviewType`: `InterviewType` (`Technical` | `HR` | `Behavioral` | `Mixed`)
    *   `duration`: `number` (Target round minutes length)
    *   `status`: `'in_progress' | 'completed'`
    *   `score`: `number` (Final overall percentage 0-100)
    *   `questions`: `InterviewQuestion[]` (Sequential list of questions asked, answers transcribing, and real-time scores)
    *   `feedback`: `InterviewFeedback` (Aggregated strengths, deficits, suggestions, and hiring status)
    *   `createdAt`: `string` (ISO date)

*   **Resume Schema (`Resume`):**
    *   `id`: `string` (Unique file identifier)
    *   `userId`: `string` (Relates to parent candidate)
    *   `fileName`: `string` (Parsed document name)
    *   `extractedText`: `string` (Extracted plain body)
    *   `analysis`: `ResumeAnalysis` (GPT-4o derived skill vectors, missing ATS keywords, improvement suggestions, and custom interview questions)

---

## 2. API Endpoint Catalog

### Authentication
*   `POST /api/auth/signup`: Registers a new user account (first user defaults to admin).
*   `POST /api/auth/login`: Validates password matching and returns a session token.
*   `GET /api/auth/me`: Retrieves current candidate session metadata.

### Mock Interview Rounds
*   `POST /api/interviews`: Creates a new mock interview session and prompts GPT-4o for Question 1.
*   `GET /api/interviews`: Compiles all practice logs and scorecards for the current user.
*   `GET /api/interviews/:id`: Fetches the active question state, timeline, and evaluations.
*   `POST /api/interviews/:id/answer`: Accepts an answered response (verbal/typed). Evaluates it immediately via GPT-4o, and generates the next follow-up question or triggers the final board scorecard report.
*   `GET /api/interviews/:id/tts/:questionIndex`: Speaks the question aloud. Streams back binary mp3 files using **OpenAI TTS-1** dynamically.
*   `POST /api/interviews/transcribe`: Accepts a recorded candidate audio blob and transcribes it using **OpenAI Whisper-1**.
*   `DELETE /api/interviews/:id`: Purges historical interview logs.

### Resume Parser & Analyzer
*   `POST /api/resumes/analyze`: Accepts document content, invokes GPT-4o to isolate ATS keywords/deficits, and saves the analysis record.
*   `GET /api/resumes`: Retrieves parsed resumes list for active session.
*   `DELETE /api/resumes/:id`: Purges saved resume document records.

### Code Whiteboard Sandbox
*   `POST /api/coding/challenge`: Dynamically drafts targeted algorithmic challenges matching candidates' seniority.
*   `POST /api/coding/evaluate`: Reviews submitted code blocks, returning O(N) space/time metrics and optimizations.

### Analytics & Administration
*   `GET /api/user/stats`: Computes radar and progress histories, identifying category deficits.
*   `GET /api/admin/stats`: Site-wide metrics dashboards (admin restricted).

---

## 3. Local Installation & Launch Guide

Follow these steps to spin up the application on your computer:

### Prerequisites
*   Ensure **Node.js v18+** is installed on your computer.

### Step 1: Install Dependencies
Open a command prompt in the project root directory and run:
```bash
npm install
```

### Step 2: Configure Environment Variables
Create a file named `.env` in the root directory and specify your OpenAI credentials:
```env
OPENAI_API_KEY="sk-proj-YourActualOpenAISecretAPIKeyHere"
NODE_ENV="development"
```

### Step 3: Run the Development Server
Launch the full-stack server (binds automatically to Express and Vite on port `3000`):
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser to start practicing!

### Step 4: Build for Production Production Deploys
Compile the static React bundles and bundle the Express backend code with esbuild:
```bash
npm run build
```
Start the high-performance compiled server:
```bash
npm start
```
The compiled files are cleanly housed in `dist/`, including the self-contained production backend bundle `dist/server.cjs`.

---

## 4. Key Deployment Highlights

*   **Cloud Run / Docker Deployments:** The package includes native binds to host `0.0.0.0` and port `3000` inside `server.ts` making it immediately ready for Docker container deployments.
*   **Dynamic API Key Syncing:** If you are deploying for users who want to supply their own keys, they can enter them in the settings panel. Our client app automatically routes custom local storage keys in headers, which override server defaults seamlessly.
