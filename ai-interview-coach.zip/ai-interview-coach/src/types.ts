export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  createdAt: string;
  isAdmin?: boolean;
}

export type InterviewType = 'Technical' | 'HR' | 'Behavioral' | 'Mixed';

export type ExperienceLevel = 'Fresher' | 'Junior' | 'Mid-Level' | 'Senior';

export type HiringDecision = 'Strong Hire' | 'Hire' | 'Borderline' | 'No Hire';

export interface InterviewFeedback {
  overallScore: number;
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
  hiringDecision: HiringDecision;
}

export interface AnswerEvaluation {
  technicalAccuracy: number; // 1-10
  communication: number; // 1-10
  confidence: number; // 1-10
  problemSolving: number; // 1-10
  clarity: number; // 1-10
  score: number; // 1-10 average
  feedback: string;
  suggestions: string;
}

export interface InterviewQuestion {
  id: string;
  questionText: string;
  answerText?: string;
  evaluation?: AnswerEvaluation;
  createdAt: string;
}

export interface Interview {
  id: string;
  userId: string;
  jobRole: string;
  experienceLevel: ExperienceLevel;
  interviewType: InterviewType;
  duration: number; // in minutes
  status: 'in_progress' | 'completed';
  score?: number; // 0-100 overall
  feedback?: InterviewFeedback;
  questions: InterviewQuestion[];
  createdAt: string;
}

export interface ResumeAnalysis {
  skills: string[];
  experience: string;
  missingKeywords: string[];
  improvements: string[];
  suggestedQuestions: string[];
}

export interface Resume {
  id: string;
  userId: string;
  fileName: string;
  extractedText: string;
  analysis: ResumeAnalysis;
  createdAt: string;
}

export interface CodingChallenge {
  id: string;
  title: string;
  description: string;
  starterCode: string;
  language: string;
  testCases: { input: string; output: string }[];
  solution?: string;
}

export interface CodeReview {
  correctness: string;
  complexityAnalysis: {
    time: string;
    space: string;
  };
  optimizationSuggestions: string[];
  score: number; // 1-100
}

export interface AppSettings {
  openaiApiKey?: string;
  theme: 'light' | 'dark';
}
