import React, { useState, useEffect } from 'react';
import { useTheme } from './ThemeContext.js';
import { 
  Briefcase, 
  Award, 
  Settings, 
  Clock, 
  Brain, 
  Play, 
  Sparkles, 
  FileText,
  AlertCircle
} from 'lucide-react';
import { ExperienceLevel, InterviewType } from '../types.js';

interface InterviewSetupProps {
  onStartInterview: (config: {
    jobRole: string;
    experienceLevel: ExperienceLevel;
    interviewType: InterviewType;
    duration: number;
    resumeText?: string;
  }) => void;
  authToken: string;
}

export default function InterviewSetup({ onStartInterview, authToken }: InterviewSetupProps) {
  const { theme } = useTheme();
  
  const [jobRole, setJobRole] = useState('Software Engineer');
  const [experienceLevel, setExperienceLevel] = useState<ExperienceLevel>('Mid-Level');
  const [interviewType, setInterviewType] = useState<InterviewType>('Technical');
  const [duration, setDuration] = useState(10); // minutes
  const [useResume, setUseResume] = useState(false);
  const [resumeText, setResumeText] = useState('');
  const [savedResumes, setSavedResumes] = useState<any[]>([]);
  const [selectedResumeId, setSelectedResumeId] = useState('');
  const [loadingResumes, setLoadingResumes] = useState(false);
  const [starting, setStarting] = useState(false);

  // Pre-load saved resumes if available
  useEffect(() => {
    async function loadResumes() {
      try {
        setLoadingResumes(true);
        const res = await fetch('/api/resumes', {
          headers: { 'Authorization': `Bearer ${authToken}` }
        });
        if (res.ok) {
          const data = await res.json();
          setSavedResumes(data.resumes || []);
          if (data.resumes && data.resumes.length > 0) {
            setSelectedResumeId(data.resumes[0].id);
            setResumeText(data.resumes[0].extractedText);
          }
        }
      } catch (err) {
        console.error('Failed to load saved resumes for grounding:', err);
      } finally {
        setLoadingResumes(false);
      }
    }
    loadResumes();
  }, [authToken]);

  const handleResumeSelectionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const id = e.target.value;
    setSelectedResumeId(id);
    if (id === 'custom') {
      setResumeText('');
    } else {
      const match = savedResumes.find(r => r.id === id);
      if (match) {
        setResumeText(match.extractedText);
      }
    }
  };

  const handleLaunch = async (e: React.FormEvent) => {
    e.preventDefault();
    setStarting(true);
    try {
      await onStartInterview({
        jobRole,
        experienceLevel,
        interviewType,
        duration,
        resumeText: useResume && resumeText ? resumeText : undefined
      });
    } catch (err) {
      console.error(err);
    } finally {
      setStarting(false);
    }
  };

  const roles = [
    'Software Engineer',
    'AI Engineer',
    'Data Analyst',
    'Data Scientist',
    'Web Developer',
    'Product Manager',
    'System Architect',
    'DevOps Engineer'
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-8 text-zinc-900 dark:text-zinc-100 transition-colors duration-300">
      
      {/* Title Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex p-3 bg-gradient-to-tr from-indigo-500 to-violet-600 rounded-2xl text-white shadow-lg shadow-indigo-500/10 mb-2">
          <Brain className="w-6 h-6" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-sans font-extrabold tracking-tight">Configure Your Board Panel</h1>
        <p className="text-xs text-zinc-500 max-w-lg mx-auto">
          Tailor target roles, difficulty layers, and assessment length to launch a personalized simulated panel run.
        </p>
      </div>

      <form onSubmit={handleLaunch} className="glass-panel p-6 sm:p-8 rounded-3xl shadow-xl space-y-6">
        
        {/* Basic Config Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Job Role select */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-600 dark:text-zinc-400 flex items-center space-x-1.5">
              <Briefcase className="w-3.5 h-3.5 text-indigo-500" />
              <span>Target Professional Role</span>
            </label>
            <select
              id="setup-job-role"
              value={jobRole}
              onChange={(e) => setJobRole(e.target.value)}
              className="w-full px-4 py-3 rounded-xl text-sm border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] backdrop-blur-md focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-zinc-900 dark:text-white transition"
            >
              {roles.map((r) => (
                <option key={r} value={r} className="dark:bg-slate-950">{r}</option>
              ))}
              <option value="Custom Role" className="dark:bg-slate-950">Custom / Other Role</option>
            </select>
            {jobRole === 'Custom Role' && (
              <input
                id="setup-custom-role"
                type="text"
                placeholder="e.g. Mobile Developer"
                onChange={(e) => setJobRole(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl text-sm border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] backdrop-blur-md focus:outline-none text-zinc-900 dark:text-white mt-2"
                required
              />
            )}
          </div>

          {/* Experience Level select */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-600 dark:text-zinc-400 flex items-center space-x-1.5">
              <Award className="w-3.5 h-3.5 text-indigo-500" />
              <span>Seniority Experience Level</span>
            </label>
            <select
              id="setup-experience-level"
              value={experienceLevel}
              onChange={(e) => setExperienceLevel(e.target.value as ExperienceLevel)}
              className="w-full px-4 py-3 rounded-xl text-sm border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] backdrop-blur-md focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-zinc-900 dark:text-white transition"
            >
              <option value="Fresher" className="dark:bg-slate-950">Fresher (Entry Level)</option>
              <option value="Junior" className="dark:bg-slate-950">Junior (1-2 Years)</option>
              <option value="Mid-Level" className="dark:bg-slate-950">Mid-Level (3-5 Years)</option>
              <option value="Senior" className="dark:bg-slate-950">Senior (5+ Years / Lead)</option>
            </select>
          </div>

          {/* Interview Type select */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-600 dark:text-zinc-400 flex items-center space-x-1.5">
              <Settings className="w-3.5 h-3.5 text-indigo-500" />
              <span>Mock Interview Focus</span>
            </label>
            <select
              id="setup-interview-type"
              value={interviewType}
              onChange={(e) => setInterviewType(e.target.value as InterviewType)}
              className="w-full px-4 py-3 rounded-xl text-sm border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] backdrop-blur-md focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-zinc-900 dark:text-white transition"
            >
              <option value="Technical" className="dark:bg-slate-950">Technical Algorithms & Architecture</option>
              <option value="HR" className="dark:bg-slate-950">HR Culture & Core Background</option>
              <option value="Behavioral" className="dark:bg-slate-950">Behavioral (STAR Structured Methodology)</option>
              <option value="Mixed" className="dark:bg-slate-950">Mixed Boardroom Generalist Round</option>
            </select>
          </div>

          {/* Interview Duration select */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-600 dark:text-zinc-400 flex items-center space-x-1.5">
              <Clock className="w-3.5 h-3.5 text-indigo-500" />
              <span>Interview Duration (Target questions count)</span>
            </label>
            <select
              id="setup-duration"
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="w-full px-4 py-3 rounded-xl text-sm border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] backdrop-blur-md focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-zinc-900 dark:text-white transition"
            >
              <option value={5} className="dark:bg-slate-950">5 Minutes (3 Questions - Sprint)</option>
              <option value={10} className="dark:bg-slate-950">10 Minutes (5 Questions - Standard)</option>
              <option value={15} className="dark:bg-slate-950">15 Minutes (8 Questions - Thorough)</option>
              <option value={30} className="dark:bg-slate-950">30 Minutes (12 Questions - Panel Simulation)</option>
            </select>
          </div>
        </div>

        {/* Dynamic Resume Grounding Panel */}
        <div className="border-t border-zinc-200/60 dark:border-white/10 pt-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-xs font-semibold flex items-center space-x-1.5 text-zinc-700 dark:text-zinc-300">
                <FileText className="w-4 h-4 text-indigo-500" />
                <span>Ground Questions in Resume context</span>
              </span>
              <span className="text-[10px] text-zinc-500 dark:text-slate-400 mt-0.5">Allow the AI to tailor questions specifically to your past roles and stack.</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input 
                id="toggle-ground-resume"
                type="checkbox" 
                checked={useResume} 
                onChange={() => setUseResume(!useResume)} 
                className="sr-only peer" 
              />
              <div className="w-11 h-6 bg-zinc-200 dark:bg-zinc-800 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
            </label>
          </div>

          {useResume && (
            <div className="space-y-4 bg-white/20 dark:bg-white/[0.02] p-4 rounded-2xl border border-zinc-200/60 dark:border-white/5 animate-fadeIn text-xs backdrop-blur-md">
              {savedResumes.length > 0 ? (
                <div className="space-y-2">
                  <label className="font-semibold text-zinc-500">Select Grounding Document</label>
                  <select
                    id="setup-resume-picker"
                    value={selectedResumeId}
                    onChange={handleResumeSelectionChange}
                    className="w-full px-3 py-2 rounded-lg border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] text-zinc-900 dark:text-white focus:outline-none"
                  >
                    {savedResumes.map(r => (
                      <option key={r.id} value={r.id} className="dark:bg-slate-950">{r.fileName} (Parsed {new Date(r.createdAt).toLocaleDateString()})</option>
                    ))}
                    <option value="custom" className="dark:bg-slate-950">Paste plain text resume content instead...</option>
                  </select>
                </div>
              ) : (
                <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-700 dark:text-indigo-400 rounded-xl flex items-start space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>No pre-analyzed resumes found. You can paste copy-pasted resume text content in the text-area below.</span>
                </div>
              )}

              {(selectedResumeId === 'custom' || savedResumes.length === 0) && (
                <div className="space-y-2">
                  <label className="font-semibold text-zinc-500">Paste Plain Text Resume</label>
                  <textarea
                    id="setup-resume-paste-text"
                    rows={4}
                    value={resumeText}
                    onChange={(e) => setResumeText(e.target.value)}
                    placeholder="Paste skills, experiences, and past projects here..."
                    className="w-full px-3 py-2.5 rounded-xl border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] text-zinc-900 dark:text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Action Button */}
        <button
          id="btn-launch-interview"
          type="submit"
          disabled={starting}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-500 to-emerald-500 text-white font-semibold text-sm shadow-lg shadow-indigo-500/20 hover:shadow-indigo-500/35 hover:-translate-y-0.5 disabled:opacity-50 disabled:pointer-events-none transition duration-200 cursor-pointer flex items-center justify-center space-x-2"
        >
          {starting ? (
            <>
              <span className="animate-spin border-2 border-white/30 border-t-white rounded-full w-4 h-4 mr-2" />
              <span>Prompting GPT-4o for target questions...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>Enter Simulated Boardroom Round</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}
