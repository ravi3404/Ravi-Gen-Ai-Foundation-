import { useTheme } from './ThemeContext.js';
import { motion } from 'motion/react';
import { Sparkles, Brain, Mic, Code2, Award, ArrowRight, ShieldCheck, Zap, ChevronRight, Play } from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
  onLogin: () => void;
}

export default function LandingPage({ onGetStarted, onLogin }: LandingPageProps) {
  const { theme } = useTheme();

  const features = [
    {
      icon: <Mic className="w-5 h-5 text-indigo-500" />,
      title: "Voice-First Mock Practice",
      description: "Ask and answer mock questions aloud. Built-in OpenAI Text-to-Speech (TTS) vocalizes questions, and Whisper transcribes answers."
    },
    {
      icon: <Brain className="w-5 h-5 text-purple-500" />,
      title: "GPT-4o Cognitive Adaptation",
      description: "The AI Coach listens and adapts questions dynamically based on the depth, structure, and correctness of your previous answers."
    },
    {
      icon: <Code2 className="w-5 h-5 text-pink-500" />,
      title: "Whiteboard Coding Round",
      description: "Test algorithmic capability with a full markdown sandbox. Get complete space/time complexity reviews and structural refactor suggestions."
    },
    {
      icon: <Award className="w-5 h-5 text-amber-500" />,
      title: "Real-Time 1-10 Rubrics",
      description: "Instant score breakdown across technical accuracy, problem solving, answer clarity, confidence under pressure, and communication."
    }
  ];

  const steps = [
    {
      num: "01",
      title: "Configure Key & Role",
      desc: "Connect your OpenAI API key and choose from Software Engineering, Data Analytics, PM, AI Engineering, or custom roles."
    },
    {
      num: "02",
      title: "Dynamic AI Conversation",
      desc: "Simulate pressure-filled behavioral or technical panel rounds. Answer verbally or typed. The AI follows up dynamically."
    },
    {
      num: "03",
      title: "Review Metrics Map",
      desc: "Receive hiring feedback from Strong Hire to No Hire, accompanied by a category score matrix and detailed area optimizations."
    }
  ];

  return (
    <div className="relative min-h-[calc(100vh-4rem)] bg-transparent text-zinc-900 dark:text-zinc-50 overflow-hidden transition-colors duration-300">
      {/* Hero Section */}
      <section className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20 sm:pt-24 sm:pb-28">
        <div className="text-center">
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 dark:bg-indigo-950/40 border border-indigo-500/20 text-indigo-700 dark:text-indigo-300 text-xs font-semibold tracking-wide mb-8 backdrop-blur-md"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-500 dark:text-emerald-400" />
            <span>Deploying Advanced OpenAI GPT-4o, Whisper & TTS Engines</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl sm:text-6xl font-sans font-extrabold tracking-tight bg-gradient-to-b from-zinc-900 via-zinc-800 to-zinc-600 dark:from-white dark:via-zinc-100 dark:to-zinc-400 bg-clip-text text-transparent leading-none max-w-4xl mx-auto"
          >
            Master Your Next Interview with an AI Boardroom Coach
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-6 text-lg sm:text-xl text-zinc-600 dark:text-slate-400 max-w-2xl mx-auto font-normal leading-relaxed"
          >
            Practice real-time technical and behavioral panels using state-of-the-art voice synthesis, live code execution assessment, and deep dynamic follow-ups.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <button
              id="hero-cta-get-started"
              onClick={onGetStarted}
              className="w-full sm:w-auto flex items-center justify-center space-x-2 px-8 py-4 rounded-2xl bg-gradient-to-r from-indigo-500 to-emerald-500 text-white font-semibold text-base shadow-xl shadow-indigo-500/20 hover:shadow-indigo-500/35 hover:-translate-y-0.5 transition-all duration-200"
            >
              <span>Practice Mock Interview</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            <button
              id="hero-cta-login"
              onClick={onLogin}
              className="w-full sm:w-auto flex items-center justify-center space-x-2 px-8 py-4 rounded-2xl border border-zinc-200 dark:border-white/10 bg-white/40 dark:bg-white/5 hover:bg-white/60 dark:hover:bg-white/10 font-semibold text-base text-zinc-700 dark:text-zinc-300 transition-all duration-200 backdrop-blur-md"
            >
              <span>Explore Dashboard</span>
              <ChevronRight className="w-5 h-5" />
            </button>
          </motion.div>
        </div>

        {/* Dashboard Visual Mockup Frame */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-16 sm:mt-20 max-w-5xl mx-auto rounded-3xl border border-zinc-200/80 dark:border-white/10 bg-white/40 dark:bg-[#0f172a]/40 p-4 backdrop-blur-2xl shadow-2xl"
        >
          <div className="rounded-2xl overflow-hidden border border-zinc-200 dark:border-white/5 bg-zinc-950 p-6 relative">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4 mb-6">
              <div className="flex items-center space-x-2">
                <span className="w-3 h-3 rounded-full bg-red-500" />
                <span className="w-3 h-3 rounded-full bg-yellow-500" />
                <span className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-xs text-zinc-500 font-mono pl-2">ai-coach-terminal.sh</span>
              </div>
              <div className="flex items-center space-x-1.5 px-3 py-1 rounded-lg bg-zinc-900 border border-zinc-800">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-ping" />
                <span className="text-[10px] text-zinc-400 font-mono">Whisper Active</span>
              </div>
            </div>

            <div className="space-y-4 font-mono text-xs sm:text-sm text-zinc-300">
              <p className="text-zinc-500">{"// AI Interviewer Question #1"}</p>
              <p className="text-indigo-400 font-semibold text-sm">"Can you explain the difference between optimistic and pessimistic locking in database transaction management?"</p>
              
              <div className="pl-4 border-l-2 border-indigo-500/40 py-1 space-y-2 mt-4">
                <p className="text-zinc-500">{"// Candidate Answer (transcribed via Whisper)"}</p>
                <p className="text-zinc-200">"Optimistic locking assumes conflicts are rare, so it doesn't hold locks, it just checks for modifications at commit time using versions. Pessimistic locking locks the records immediately to block other writers."</p>
              </div>

              <div className="p-4 rounded-xl bg-zinc-900/50 border border-zinc-800 mt-6 space-y-2">
                <div className="flex items-center justify-between text-xs text-zinc-400 font-semibold border-b border-zinc-800/50 pb-2">
                  <span>GPT-4o Answer Evaluation</span>
                  <span className="text-emerald-400 font-bold font-sans text-sm">Score: 9/10</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-2">
                  <div className="bg-zinc-900 p-2 rounded border border-zinc-800 text-center">
                    <p className="text-[9px] text-zinc-500">Technical</p>
                    <p className="text-zinc-300 font-bold">9/10</p>
                  </div>
                  <div className="bg-zinc-900 p-2 rounded border border-zinc-800 text-center">
                    <p className="text-[9px] text-zinc-500">Communication</p>
                    <p className="text-zinc-300 font-bold">8/10</p>
                  </div>
                  <div className="bg-zinc-900 p-2 rounded border border-zinc-800 text-center">
                    <p className="text-[9px] text-zinc-500">Confidence</p>
                    <p className="text-zinc-300 font-bold">10/10</p>
                  </div>
                  <div className="bg-zinc-900 p-2 rounded border border-zinc-800 text-center">
                    <p className="text-[9px] text-zinc-500">Problem Solving</p>
                    <p className="text-zinc-300 font-bold">8/10</p>
                  </div>
                  <div className="bg-zinc-900 p-2 rounded border border-zinc-800 text-center">
                    <p className="text-[9px] text-zinc-500">Clarity</p>
                    <p className="text-zinc-300 font-bold">9/10</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white/30 dark:bg-white/[0.01] border-y border-zinc-200/60 dark:border-white/5 backdrop-blur-xl transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl font-sans font-bold tracking-tight text-zinc-900 dark:text-white">
              SaaS Level Training Architecture
            </h2>
            <p className="mt-4 text-base text-zinc-600 dark:text-slate-400">
              An exhaustive suite designed to cover technical competence, communication rhythm, and whiteboard problem-solving frameworks.
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feat, idx) => (
              <div 
                key={idx}
                className="p-6 rounded-2xl glass-panel hover:border-indigo-500/30 hover:shadow-lg hover:shadow-indigo-500/[0.02] transition-all duration-300"
              >
                <div className="p-3 bg-white/80 dark:bg-slate-900/80 border border-zinc-100 dark:border-white/5 rounded-xl w-fit shadow-sm">
                  {feat.icon}
                </div>
                <h3 className="mt-5 text-base font-semibold text-zinc-900 dark:text-white">
                  {feat.title}
                </h3>
                <p className="mt-2 text-xs text-zinc-600 dark:text-slate-400 leading-relaxed">
                  {feat.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 sm:py-28 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-sans font-bold tracking-tight text-zinc-900 dark:text-white">
            How It Works
          </h2>
          <p className="mt-4 text-base text-zinc-600 dark:text-slate-400">
            From setup to analytics dashboards, prepare systematically for competitive roles.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, idx) => (
            <div key={idx} className="relative group p-6 rounded-2xl border border-dashed border-zinc-200 dark:border-white/10 bg-white/20 dark:bg-white/[0.02] backdrop-blur-md">
              <span className="absolute -top-6 left-6 font-mono font-extrabold text-4xl text-indigo-500/30 dark:text-indigo-500/20 group-hover:text-indigo-500 transition-colors duration-300">
                {step.num}
              </span>
              <h3 className="text-base font-bold text-zinc-900 dark:text-white mt-4">
                {step.title}
              </h3>
              <p className="mt-2.5 text-xs text-zinc-600 dark:text-slate-400 leading-relaxed">
                {step.desc}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <button
            id="how-it-works-cta"
            onClick={onGetStarted}
            className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm transition-all duration-200 shadow-lg shadow-indigo-500/20 hover:-translate-y-0.5"
          >
            <span>Launch Your Training Session Now</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* Bottom Showcase Trust banner */}
      <section className="py-12 border-t border-zinc-200/60 dark:border-white/5 text-center text-xs text-zinc-500 max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center justify-center gap-8 px-4 opacity-70">
          <div className="flex items-center space-x-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>Secure SQL Database</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <Zap className="w-4 h-4 text-amber-500" />
            <span>Real-time Dynamic Evaluators</span>
          </div>
        </div>
      </section>
    </div>
  );
}
