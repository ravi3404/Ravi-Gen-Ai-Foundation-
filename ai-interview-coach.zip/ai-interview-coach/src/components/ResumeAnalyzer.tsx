import React, { useState, useEffect } from 'react';
import { useTheme } from './ThemeContext.js';
import { 
  FileText, 
  UploadCloud, 
  CheckCircle, 
  AlertTriangle, 
  Sparkles, 
  Trash2, 
  Briefcase, 
  Play,
  HelpCircle,
  RefreshCw,
  Info
} from 'lucide-react';
import { Resume } from '../types.js';

interface ResumeAnalyzerProps {
  authToken: string;
  onLaunchInterviewWithResume: (resumeText: string) => void;
}

export default function ResumeAnalyzer({ authToken, onLaunchInterviewWithResume }: ResumeAnalyzerProps) {
  const { theme } = useTheme();
  
  const [fileName, setFileName] = useState('');
  const [pasteText, setPasteText] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [savedResumes, setSavedResumes] = useState<Resume[]>([]);
  const [activeResume, setActiveResume] = useState<Resume | null>(null);
  const [loading, setLoading] = useState(true);

  // Fetch saved analyses on mount
  const fetchSavedResumes = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/resumes', {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setSavedResumes(data.resumes || []);
        if (data.resumes && data.resumes.length > 0) {
          setActiveResume(data.resumes[0]);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSavedResumes();
  }, [authToken]);

  // Support drag & drop or file loading
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setFileName(file.name);
    
    // Read file text directly (since we support standard txt, md, or code files)
    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target?.result as string;
      setPasteText(text);
    };
    reader.readAsText(file);
  };

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pasteText.trim()) return;

    setAnalyzing(true);
    const resolvedFileName = fileName || 'pasted_resume_document.txt';

    try {
      const res = await fetch('/api/resumes/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          fileName: resolvedFileName,
          textContent: pasteText
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Analysis failed.');

      const newResume: Resume = data.resume;
      setSavedResumes(prev => [newResume, ...prev]);
      setActiveResume(newResume);
      setPasteText('');
      setFileName('');
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Error occurred during resume parser invocation.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleDeleteResume = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this resume analysis?')) return;

    try {
      const res = await fetch(`/api/resumes/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      if (res.ok) {
        setSavedResumes(prev => prev.filter(r => r.id !== id));
        if (activeResume?.id === id) {
          setActiveResume(savedResumes.find(r => r.id !== id) || null);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-zinc-900 dark:text-zinc-100 transition-colors duration-300">
      
      {/* Title Header */}
      <div>
        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
          OpenAI GPT-4o Resume Parser
        </span>
        <h1 className="text-2xl font-sans font-extrabold tracking-tight">Resume Optimization Sandbox</h1>
        <p className="text-xs text-zinc-500 mt-1">
          Upload or paste your professional resume. Extract key skill vectors, cross-check missing keywords, and draft optimized bullet points.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Upload or Pasting Workspace, plus Saved History */}
        <div className="lg:col-span-5 space-y-6">
          <div className="glass-panel p-6 rounded-3xl space-y-4">
            <h3 className="text-sm font-extrabold flex items-center space-x-2 border-b border-zinc-200/60 dark:border-white/10 pb-3">
              <UploadCloud className="w-5 h-5 text-indigo-500" />
              <span>Input Documents</span>
            </h3>

            <form onSubmit={handleAnalyze} className="space-y-4">
              {/* File Upload Selector */}
              <div className="border border-dashed border-zinc-200/60 dark:border-white/10 p-5 rounded-2xl text-center hover:border-indigo-500/40 hover:bg-white/10 dark:hover:bg-white/[0.03] transition cursor-pointer relative backdrop-blur-sm">
                <input 
                  id="resume-file-input"
                  type="file" 
                  accept=".txt,.md,.pdf,.json" 
                  onChange={handleFileChange} 
                  className="absolute inset-0 opacity-0 cursor-pointer" 
                />
                <UploadCloud className="w-8 h-8 text-indigo-500/60 mx-auto mb-2" />
                <p className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                  {fileName ? fileName : 'Upload Resume Document'}
                </p>
                <span className="text-[9px] text-zinc-500 block mt-1">Supports TXT, MD, PDF or JSON text</span>
              </div>

              {/* Paste Textbox alternative */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider block">Or Paste Resume Text Content</label>
                <textarea
                  id="resume-paste-input"
                  rows={6}
                  value={pasteText}
                  onChange={(e) => setPasteText(e.target.value)}
                  placeholder="Paste experience, target stack skills, summary details here..."
                  className="w-full px-3 py-2.5 rounded-xl border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 text-zinc-900 dark:text-white"
                  required={!fileName}
                />
              </div>

              {/* Analyze button */}
              <button
                id="btn-analyze-resume"
                type="submit"
                disabled={analyzing || !pasteText.trim()}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-emerald-500 text-white text-xs font-semibold shadow-md shadow-indigo-500/15 disabled:opacity-50 hover:-translate-y-0.5 transition cursor-pointer flex items-center justify-center space-x-2"
              >
                {analyzing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Analyzing stack parameters...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Parse & Analyze Resume</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* List of previously parsed resumes */}
          <div className="glass-panel p-6 rounded-3xl space-y-4">
            <h3 className="text-sm font-extrabold flex items-center space-x-2 border-b border-zinc-200/60 dark:border-white/10 pb-3">
              <FileText className="w-5 h-5 text-indigo-500" />
              <span>Analyses Records</span>
            </h3>

            {loading ? (
              <p className="text-center py-4 text-[10px] text-zinc-500">Loading historical files...</p>
            ) : savedResumes.length === 0 ? (
              <div className="text-center py-6 text-zinc-400">
                <HelpCircle className="w-6 h-6 mx-auto text-zinc-400/50 mb-2" />
                <p className="text-[10px]">No parsed resumes found in database.</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {savedResumes.map(r => (
                  <div
                    key={r.id}
                    onClick={() => setActiveResume(r)}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition ${
                      activeResume?.id === r.id 
                        ? 'border-indigo-500/40 bg-indigo-50/30 dark:bg-indigo-950/20' 
                        : 'border-zinc-100 dark:border-zinc-800/80 hover:bg-zinc-50/50 dark:hover:bg-zinc-900/30'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 overflow-hidden">
                      <FileText className="w-4 h-4 text-zinc-400 shrink-0" />
                      <div className="overflow-hidden">
                        <span className="text-xs font-bold block truncate text-zinc-800 dark:text-zinc-200">{r.fileName}</span>
                        <span className="text-[9px] text-zinc-500 block mt-0.5">{new Date(r.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>

                    <button
                      onClick={(e) => handleDeleteResume(r.id, e)}
                      className="p-1 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-zinc-400 hover:text-red-500 shrink-0 transition"
                      title="Delete Entry"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Visualizing the Selected Resume analysis report */}
        <div className="lg:col-span-7">
          {!activeResume ? (
            <div className="glass-panel p-12 rounded-3xl text-center space-y-3">
              <FileText className="w-12 h-12 mx-auto text-zinc-300 dark:text-zinc-700" />
              <h3 className="font-bold text-base">Select or Parse a Resume</h3>
              <p className="text-xs text-zinc-500 dark:text-slate-400 max-w-sm mx-auto leading-relaxed">
                Provide a resume document in the workspace on the left. The AI coach will generate optimized bullet reviews, skills extracted, and matching mock templates.
              </p>
            </div>
          ) : (
            <div className="glass-panel p-6 sm:p-8 rounded-3xl space-y-6">
              
              {/* Report Header */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-zinc-200/60 dark:border-white/10 pb-4">
                <div>
                  <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-extrabold uppercase tracking-wide">Analysis Log for</span>
                  <h2 className="text-lg font-bold">{activeResume.fileName}</h2>
                </div>

                <button
                  id="btn-launch-grounded-interview"
                  onClick={() => onLaunchInterviewWithResume(activeResume.extractedText)}
                  className="flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-zinc-900 dark:bg-zinc-100 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 text-xs font-semibold transition shadow-sm"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Practice Grounded Mock</span>
                </button>
              </div>

              {/* Skills Extracted */}
              <div className="space-y-2">
                <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider flex items-center space-x-1">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Parsed Professional Skills</span>
                </span>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {activeResume.analysis.skills.map(s => (
                    <span key={s} className="px-2.5 py-1 rounded-lg bg-white/25 dark:bg-white/[0.04] text-zinc-800 dark:text-zinc-200 text-[10px] font-semibold border border-zinc-200/40 dark:border-white/10">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Missing keywords warnings */}
              <div className="space-y-2 pt-2 border-t border-zinc-200/60 dark:border-white/10">
                <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider flex items-center space-x-1">
                  <AlertTriangle className="w-4 h-4 text-amber-500" />
                  <span>Missing Crucial Recruitment Keywords</span>
                </span>
                <p className="text-[10px] text-zinc-500 dark:text-slate-400 leading-relaxed">Consider adding these exact terms to match screening applicant tracking systems (ATS):</p>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {activeResume.analysis.missingKeywords.map(kw => (
                    <span key={kw} className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400 text-[10px] font-semibold">
                      {kw}
                    </span>
                  ))}
                </div>
              </div>

              {/* Resume Improvements list */}
              <div className="space-y-3 pt-4 border-t border-zinc-200/60 dark:border-white/10">
                <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider block">Recommended Optimizations</span>
                <ul className="space-y-2">
                  {activeResume.analysis.improvements.map((imp, index) => (
                    <li key={index} className="text-xs text-zinc-600 dark:text-slate-400 flex items-start space-x-2 leading-relaxed">
                      <span className="text-indigo-500 font-bold shrink-0">•</span>
                      <span>{imp}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Sample interview questions derived */}
              <div className="space-y-3 pt-4 border-t border-zinc-200/60 dark:border-white/10">
                <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider flex items-center space-x-1">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span>Resume-Tailored Practice Prompts</span>
                </span>
                <p className="text-[10px] text-zinc-500 dark:text-slate-400 leading-relaxed">The AI Coach compiled these specific questions based on your highlighted historical projects:</p>
                <div className="space-y-2 pt-1">
                  {activeResume.analysis.suggestedQuestions.map((q, idx) => (
                    <div 
                      key={idx} 
                      className="p-3 rounded-xl bg-white/20 dark:bg-white/[0.02] border border-zinc-200/60 dark:border-white/5 font-sans font-semibold text-xs leading-relaxed text-zinc-700 dark:text-slate-300 backdrop-blur-md"
                    >
                      {idx + 1}. "{q}"
                    </div>
                  ))}
                </div>
              </div>

              {/* Summary note bottom */}
              <div className="pt-4 border-t border-zinc-200/60 dark:border-white/10 text-[10px] text-zinc-500 flex items-center space-x-1">
                <Info className="w-3.5 h-3.5 shrink-0 text-zinc-400" />
                <span>Grounding standard mock suites in this resume ensures custom conversational context.</span>
              </div>

            </div>
          )}
        </div>

      </div>
    </div>
  );
}
