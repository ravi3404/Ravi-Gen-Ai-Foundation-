import React, { useEffect, useState } from 'react';
import { useTheme } from './ThemeContext.js';
import { 
  Play, 
  Award, 
  FileText, 
  Code, 
  Calendar, 
  Trash2, 
  Clock, 
  ChevronRight, 
  Activity, 
  HelpCircle,
  TrendingUp,
  XCircle,
  Briefcase
} from 'lucide-react';
import { Interview } from '../types.js';

interface DashboardProps {
  user: { name: string; email: string; isAdmin?: boolean };
  onStartNewInterview: () => void;
  onViewReport: (interviewId: string) => void;
  onResumeTab: () => void;
  onCodingTab: () => void;
  authToken: string;
}

export default function Dashboard({ 
  user, 
  onStartNewInterview, 
  onViewReport, 
  onResumeTab, 
  onCodingTab, 
  authToken 
}: DashboardProps) {
  const { theme } = useTheme();
  const [history, setHistory] = useState<Interview[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      // Fetch user's interviews
      const resInterviews = await fetch('/api/interviews', {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      const dataInterviews = await resInterviews.json();
      if (resInterviews.ok) {
        setHistory(dataInterviews.interviews || []);
      }

      // Fetch analytics stats
      const resStats = await fetch('/api/user/stats', {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      const dataStats = await resStats.json();
      if (resStats.ok) {
        setStats(dataStats);
      }
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [authToken]);

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this interview session? This cannot be undone.')) {
      return;
    }

    try {
      const res = await fetch(`/api/interviews/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      if (res.ok) {
        fetchDashboardData();
      }
    } catch (err) {
      console.error('Failed to delete interview:', err);
    }
  };

  const getHiringBadgeColor = (decision: string) => {
    switch (decision) {
      case 'Strong Hire':
        return 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800/40';
      case 'Hire':
        return 'bg-blue-50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400 border-blue-200 dark:border-blue-800/40';
      case 'Borderline':
        return 'bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400 border-amber-200 dark:border-amber-800/40';
      case 'No Hire':
        return 'bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-400 border-red-200 dark:border-red-800/40';
      default:
        return 'bg-zinc-50 text-zinc-600 dark:bg-zinc-900 dark:text-zinc-400';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-zinc-900 dark:text-zinc-100 transition-colors duration-300">
      
      {/* Welcome Heading Panel */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 glass-panel p-6 rounded-3xl">
        <div>
          <h1 className="text-2xl font-sans font-extrabold tracking-tight">
            Welcome back, <span className="bg-gradient-to-r from-indigo-500 to-emerald-400 bg-clip-text text-transparent">{user.name}</span>
          </h1>
          <p className="text-xs text-zinc-500 dark:text-slate-400 mt-1">
            Let's prepare and simulate high-pressure tech boardroom sessions today.
          </p>
        </div>
        <button
          id="btn-start-interview-dashboard"
          onClick={onStartNewInterview}
          className="flex items-center space-x-2 px-5 py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-emerald-500 text-white font-semibold text-xs shadow-md shadow-indigo-500/10 hover:shadow-indigo-500/25 hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>Start New Mock Round</span>
        </button>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric Card 1 */}
        <div className="glass-panel p-5 rounded-2xl">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Mocks</span>
            <Activity className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="mt-2.5">
            <span className="text-2xl font-extrabold">{stats ? stats.totalInterviews : 0}</span>
            <span className="text-[10px] text-zinc-500 block mt-0.5">Sessions fully completed</span>
          </div>
        </div>

        {/* Metric Card 2 */}
        <div className="glass-panel p-5 rounded-2xl">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Average Score</span>
            <Award className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2.5">
            <span className="text-2xl font-extrabold">{stats && stats.avgScores ? `${stats.avgScores.overall}%` : '0%'}</span>
            <span className="text-[10px] text-zinc-500 block mt-0.5">Weighted performance metric</span>
          </div>
        </div>

        {/* Metric Card 3 */}
        <div className="glass-panel p-5 rounded-2xl">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Communication Metric</span>
            <TrendingUp className="w-4 h-4 text-violet-500" />
          </div>
          <div className="mt-2.5">
            <span className="text-2xl font-extrabold">{stats && stats.avgScores ? `${stats.avgScores.communication}%` : '0%'}</span>
            <span className="text-[10px] text-zinc-500 block mt-0.5">Average Whisper feedback rating</span>
          </div>
        </div>

        {/* Metric Card 4 */}
        <div className="glass-panel p-5 rounded-2xl">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Improvement Target</span>
            <XCircle className="w-4 h-4 text-red-500" />
          </div>
          <div className="mt-2.5">
            <span className="text-sm font-bold truncate block max-w-full">
              {stats && stats.weakTopics && stats.weakTopics.length > 0 ? stats.weakTopics[0] : 'None! Exceptional'}
            </span>
            <span className="text-[10px] text-zinc-500 block mt-0.5">Identified category deficit</span>
          </div>
        </div>
      </div>

      {/* Interactive Tool Suite Launchers */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-panel p-6 rounded-3xl flex flex-col justify-between hover:border-indigo-500/40 glow-indigo transition-all duration-300">
          <div>
            <div className="w-10 h-10 rounded-xl bg-indigo-500 text-white flex items-center justify-center shadow-md">
              <Play className="w-5 h-5 fill-current" />
            </div>
            <h3 className="mt-4 font-sans font-extrabold text-base">Standard Mock Interview</h3>
            <p className="text-xs text-zinc-600 dark:text-slate-400 mt-2 leading-relaxed">
              Start custom tailored simulations with full voice or text capability. Practice STAR frameworks, technical system architectures, or Mixed HR categories.
            </p>
          </div>
          <button
            onClick={onStartNewInterview}
            className="flex items-center space-x-1.5 mt-6 text-xs text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
          >
            <span>Launch mock editor</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="glass-panel p-6 rounded-3xl flex flex-col justify-between hover:border-purple-500/40 glow-violet transition-all duration-300">
          <div>
            <div className="w-10 h-10 rounded-xl bg-purple-500 text-white flex items-center justify-center shadow-md">
              <FileText className="w-5 h-5" />
            </div>
            <h3 className="mt-4 font-sans font-extrabold text-base">Resume Improver</h3>
            <p className="text-xs text-zinc-600 dark:text-slate-400 mt-2 leading-relaxed">
              Analyze your current PDF or Markdown resume with GPT-4o. Highlight missing recruitment keywords, experience phrasing deficit, and generate specialized matching questions.
            </p>
          </div>
          <button
            onClick={onResumeTab}
            className="flex items-center space-x-1.5 mt-6 text-xs text-purple-600 dark:text-purple-400 font-bold hover:underline"
          >
            <span>Launch resume analyzer</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="glass-panel p-6 rounded-3xl flex flex-col justify-between hover:border-pink-500/40 glow-pink transition-all duration-300">
          <div>
            <div className="w-10 h-10 rounded-xl bg-pink-500 text-white flex items-center justify-center shadow-md">
              <Code className="w-5 h-5" />
            </div>
            <h3 className="mt-4 font-sans font-extrabold text-base">Coding Board Sandbox</h3>
            <p className="text-xs text-zinc-600 dark:text-slate-400 mt-2 leading-relaxed">
              Tackle complex coding challenges created live by the AI Coach. Write custom solutions, check time/space optimizations, and review code blocks.
            </p>
          </div>
          <button
            onClick={onCodingTab}
            className="flex items-center space-x-1.5 mt-6 text-xs text-pink-600 dark:text-pink-400 font-bold hover:underline"
          >
            <span>Launch coding terminal</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* History and Upcoming Practice Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Practice Sessions Log */}
        <div className="lg:col-span-2 glass-panel rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-zinc-100 dark:border-white/5 pb-3">
            <h2 className="text-base font-bold flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-indigo-500" />
              <span>Practice History Logs</span>
            </h2>
            <span className="text-xs text-zinc-500">{history.length} total runs</span>
          </div>

          {loading ? (
            <div className="text-center py-10 text-xs text-zinc-400">
              Loading previous logs...
            </div>
          ) : history.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <HelpCircle className="w-8 h-8 mx-auto text-zinc-400/60" />
              <p className="text-xs text-zinc-400">No mock practice rounds recorded yet.</p>
              <button
                onClick={onStartNewInterview}
                className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold underline"
              >
                Launch your first simulation
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="text-zinc-400 font-semibold border-b border-zinc-100 dark:border-zinc-800 pb-2">
                    <th className="py-2.5">Job Role</th>
                    <th className="py-2.5">Type & Level</th>
                    <th className="py-2.5">Score</th>
                    <th className="py-2.5">Hiring Status</th>
                    <th className="py-2.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
                  {history.map((item) => (
                    <tr 
                      key={item.id}
                      onClick={() => item.status === 'completed' ? onViewReport(item.id) : null}
                      className="hover:bg-zinc-50 dark:hover:bg-zinc-900/50 cursor-pointer transition-colors"
                    >
                      <td className="py-3.5 pr-2">
                        <div className="font-semibold text-zinc-900 dark:text-white flex items-center space-x-1.5">
                          <Briefcase className="w-3.5 h-3.5 text-zinc-400" />
                          <span>{item.jobRole}</span>
                        </div>
                        <span className="text-[10px] text-zinc-400 block mt-0.5">
                          {new Date(item.createdAt).toLocaleDateString()}
                        </span>
                      </td>
                      <td className="py-3.5">
                        <span className="px-2 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 font-medium mr-1.5">
                          {item.interviewType}
                        </span>
                        <span className="text-zinc-400">{item.experienceLevel}</span>
                      </td>
                      <td className="py-3.5">
                        {item.status === 'completed' ? (
                          <span className="font-extrabold text-sm text-indigo-600 dark:text-indigo-400">
                            {item.score}%
                          </span>
                        ) : (
                          <span className="text-amber-500 font-medium italic">In Progress</span>
                        )}
                      </td>
                      <td className="py-3.5">
                        {item.status === 'completed' && item.feedback ? (
                          <span className={`px-2 py-1 rounded-md text-[10px] font-bold border ${getHiringBadgeColor(item.feedback.hiringDecision)}`}>
                            {item.feedback.hiringDecision}
                          </span>
                        ) : (
                          <span className="text-zinc-400">-</span>
                        )}
                      </td>
                      <td className="py-3.5 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end space-x-2">
                          {item.status === 'completed' ? (
                            <button
                              onClick={() => onViewReport(item.id)}
                              className="px-2.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400 text-[10px] font-semibold transition"
                            >
                              ReportCard
                            </button>
                          ) : (
                            <button
                              onClick={() => onViewReport(item.id)} // Redirecting will handle resuming
                              className="px-2.5 py-1.5 rounded-lg bg-indigo-600 text-white text-[10px] font-semibold transition hover:bg-indigo-700"
                            >
                              Resume
                            </button>
                          )}
                          <button
                            onClick={(e) => handleDelete(item.id, e)}
                            className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/20 text-zinc-400 hover:text-red-500 transition"
                            title="Delete entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Actionable Training Schedules */}
        <div className="glass-panel rounded-3xl p-6 space-y-4 flex flex-col justify-between">
          <div>
            <h2 className="text-base font-bold flex items-center space-x-2 border-b border-zinc-100 dark:border-white/5 pb-3">
              <Calendar className="w-5 h-5 text-emerald-400" />
              <span>Recommended Curriculum</span>
            </h2>
            
            <div className="space-y-4 mt-4">
              <div className="p-3 bg-white/20 dark:bg-white/[0.02] rounded-xl border border-zinc-100 dark:border-white/5 flex items-start space-x-3">
                <div className="p-2 bg-indigo-500/10 text-indigo-500 dark:text-indigo-400 rounded-lg text-xs font-mono">ST</div>
                <div>
                  <h4 className="text-xs font-bold">STAR Method Blueprint</h4>
                  <p className="text-[10px] text-zinc-500 dark:text-slate-400 mt-1">Practice structuring behavioral round examples in STAR steps.</p>
                </div>
              </div>

              <div className="p-3 bg-white/20 dark:bg-white/[0.02] rounded-xl border border-zinc-100 dark:border-white/5 flex items-start space-x-3">
                <div className="p-2 bg-violet-500/10 text-violet-500 dark:text-violet-400 rounded-lg text-xs font-mono">SD</div>
                <div>
                  <h4 className="text-xs font-bold">System Design & Latencies</h4>
                  <p className="text-[10px] text-zinc-500 dark:text-slate-400 mt-1">Converse on load balancing, optimistic locking, and horizontal shards.</p>
                </div>
              </div>

              <div className="p-3 bg-white/20 dark:bg-white/[0.02] rounded-xl border border-zinc-100 dark:border-white/5 flex items-start space-x-3">
                <div className="p-2 bg-emerald-500/10 text-emerald-500 dark:text-emerald-400 rounded-lg text-xs font-mono">TC</div>
                <div>
                  <h4 className="text-xs font-bold">Whiteboard String Algorithms</h4>
                  <p className="text-[10px] text-zinc-500 dark:text-slate-400 mt-1">Practice optimization for O(N) linear time space bounds.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-zinc-100 dark:border-white/5 mt-4 text-center">
            <span className="text-[10px] text-zinc-400 block mb-3">All practice metrics synced to file-backed database</span>
            <button
              onClick={onStartNewInterview}
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-lg shadow-indigo-500/10 transition"
            >
              Configure Training Suite
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
