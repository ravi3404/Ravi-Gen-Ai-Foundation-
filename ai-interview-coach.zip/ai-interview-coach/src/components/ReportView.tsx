import React, { useState, useEffect } from 'react';
import { useTheme } from './ThemeContext.js';
import { 
  Award, 
  ChevronDown, 
  ChevronUp, 
  CheckCircle, 
  XCircle, 
  FileText, 
  HelpCircle, 
  Briefcase, 
  TrendingUp, 
  ArrowLeft,
  ThumbsUp,
  Sliders,
  ShieldAlert
} from 'lucide-react';
import { Interview, InterviewFeedback } from '../types.js';

interface ReportViewProps {
  interviewId: string;
  authToken: string;
  onBack: () => void;
}

export default function ReportView({ interviewId, authToken, onBack }: ReportViewProps) {
  const { theme } = useTheme();
  const [interview, setInterview] = useState<Interview | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedQuestionId, setExpandedQuestionId] = useState<string | null>(null);

  useEffect(() => {
    async function loadReport() {
      try {
        setLoading(true);
        const res = await fetch(`/api/interviews/${interviewId}`, {
          headers: { 'Authorization': `Bearer ${authToken}` }
        });
        if (res.ok) {
          const data = await res.json();
          setInterview(data.interview);
          if (data.interview.questions && data.interview.questions.length > 0) {
            setExpandedQuestionId(data.interview.questions[0].id);
          }
        }
      } catch (err) {
        console.error('Failed to load interview report:', err);
      } finally {
        setLoading(false);
      }
    }
    loadReport();
  }, [interviewId]);

  const toggleExpandQuestion = (id: string) => {
    setExpandedQuestionId(prev => (prev === id ? null : id));
  };

  const getHiringColors = (decision: string) => {
    switch (decision) {
      case 'Strong Hire':
        return {
          bg: 'bg-emerald-50 dark:bg-emerald-950/20',
          border: 'border-emerald-200 dark:border-emerald-800/60',
          text: 'text-emerald-700 dark:text-emerald-400',
          desc: 'Recommended as a standout fit with highly complete structural answers.'
        };
      case 'Hire':
        return {
          bg: 'bg-blue-50 dark:bg-blue-950/20',
          border: 'border-blue-200 dark:border-blue-800/60',
          text: 'text-blue-700 dark:text-blue-400',
          desc: 'Competent, articulate, and meets or exceeds professional standard requirements.'
        };
      case 'Borderline':
        return {
          bg: 'bg-amber-50 dark:bg-amber-950/20',
          border: 'border-amber-200 dark:border-amber-800/60',
          text: 'text-amber-700 dark:text-amber-400',
          desc: 'Demonstrated initial competence, but exhibited depth gaps under drill pressure.'
        };
      case 'No Hire':
        return {
          bg: 'bg-red-50 dark:bg-red-950/20',
          border: 'border-red-200 dark:border-red-800/60',
          text: 'text-red-700 dark:text-red-400',
          desc: 'Exhibited major structural gaps in technical accuracy or communication clarity.'
        };
      default:
        return {
          bg: 'bg-zinc-50 dark:bg-zinc-900',
          border: 'border-zinc-200',
          text: 'text-zinc-600',
          desc: ''
        };
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-4rem)] text-zinc-500">
        <span className="animate-spin border-2 border-indigo-500 border-t-transparent rounded-full w-6 h-6 mb-4" />
        <span className="text-xs font-semibold">Compiling Final Boardroom Report...</span>
      </div>
    );
  }

  if (!interview || !interview.feedback) {
    return (
      <div className="text-center py-12 max-w-sm mx-auto space-y-4">
        <ShieldAlert className="w-10 h-10 text-amber-500 mx-auto" />
        <h3 className="font-bold text-base">Incomplete Practice Session</h3>
        <p className="text-xs text-zinc-400">The requested final report could not be compiled because this mock session has not been fully completed.</p>
        <button onClick={onBack} className="px-4 py-2 bg-zinc-900 text-white rounded-xl text-xs font-semibold">
          Return to Dashboard
        </button>
      </div>
    );
  }

  const { overallScore, strengths, weaknesses, recommendations, hiringDecision } = interview.feedback;
  const decisionMeta = getHiringColors(hiringDecision);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-zinc-900 dark:text-zinc-100 transition-colors duration-300">
      
      {/* Back navigation */}
      <button
        id="btn-report-back"
        onClick={onBack}
        className="inline-flex items-center space-x-1.5 text-xs text-zinc-500 hover:text-zinc-900 dark:hover:text-white font-semibold transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Dashboard</span>
      </button>

      {/* Main visual header card */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 glass-panel p-6 sm:p-8 rounded-3xl items-center">
        {/* Ring score */}
        <div className="md:col-span-3 text-center">
          <div className="relative w-36 h-36 mx-auto flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="72"
                cy="72"
                r="64"
                className="stroke-zinc-100 dark:stroke-zinc-850 fill-none"
                strokeWidth="10"
              />
              <circle
                cx="72"
                cy="72"
                r="64"
                className="stroke-indigo-500 fill-none transition-all duration-1000"
                strokeWidth="10"
                strokeDasharray={402}
                strokeDashoffset={402 - (402 * overallScore) / 100}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-extrabold font-sans">{overallScore}</span>
              <span className="text-[10px] text-zinc-400 uppercase tracking-wider font-semibold">Overall Score</span>
            </div>
          </div>
        </div>

        {/* Hiring Decision Metadata */}
        <div className="md:col-span-9 space-y-4 text-center md:text-left">
          <div className="space-y-1">
            <span className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Hiring Recommendation Badge</span>
            <div className="flex flex-col md:flex-row items-center gap-3">
              <span className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border uppercase tracking-widest ${decisionMeta.bg} ${decisionMeta.border} ${decisionMeta.text}`}>
                {hiringDecision}
              </span>
              <span className="text-xs text-zinc-500">{decisionMeta.desc}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-2 border-t border-zinc-200/60 dark:border-white/10">
            <div>
              <span className="text-[10px] text-zinc-400 font-semibold block">Role Targeted</span>
              <span className="text-xs font-bold">{interview.jobRole}</span>
            </div>
            <div>
              <span className="text-[10px] text-zinc-400 font-semibold block">Difficulty Bracket</span>
              <span className="text-xs font-bold">{interview.experienceLevel}</span>
            </div>
            <div>
              <span className="text-[10px] text-zinc-400 font-semibold block">Questions Evaluated</span>
              <span className="text-xs font-bold">{interview.questions.length} questions</span>
            </div>
          </div>
        </div>
      </div>

      {/* Strengths & Areas of Improvement check columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Strengths card */}
        <div className="glass-panel p-6 rounded-3xl">
          <h3 className="text-sm font-extrabold flex items-center space-x-2 border-b border-zinc-200/60 dark:border-white/10 pb-3 mb-4 text-emerald-500 dark:text-emerald-400">
            <CheckCircle className="w-5 h-5" />
            <span>Strengths & Core Competencies</span>
          </h3>
          <ul className="space-y-3">
            {strengths.map((str, idx) => (
              <li key={idx} className="text-xs text-zinc-600 dark:text-zinc-400 flex items-start space-x-2.5">
                <span className="h-5 w-5 bg-emerald-500/10 text-emerald-500 rounded-lg flex items-center justify-center shrink-0 font-bold font-mono text-[10px]">
                  {idx + 1}
                </span>
                <span className="leading-relaxed">{str}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Weaknesses card */}
        <div className="glass-panel p-6 rounded-3xl">
          <h3 className="text-sm font-extrabold flex items-center space-x-2 border-b border-zinc-200/60 dark:border-white/10 pb-3 mb-4 text-rose-500 dark:text-rose-400">
            <XCircle className="w-5 h-5" />
            <span>Exhibited Gaps & Deficits</span>
          </h3>
          <ul className="space-y-3">
            {weaknesses.map((weak, idx) => (
              <li key={idx} className="text-xs text-zinc-600 dark:text-zinc-400 flex items-start space-x-2.5">
                <span className="h-5 w-5 bg-red-500/10 text-red-500 rounded-lg flex items-center justify-center shrink-0 font-bold font-mono text-[10px]">
                  {idx + 1}
                </span>
                <span className="leading-relaxed">{weak}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Actionable Recommendations list */}
      <div className="glass-panel-heavy p-6 rounded-3xl bg-indigo-500/[0.04] border-indigo-500/20">
        <h3 className="text-sm font-extrabold flex items-center space-x-2 border-b border-indigo-500/15 pb-3 mb-4 text-indigo-700 dark:text-indigo-400">
          <TrendingUp className="w-5 h-5" />
          <span>Actionable Curated Recommendations</span>
        </h3>
        <ul className="space-y-4">
          {recommendations.map((rec, idx) => (
            <li key={idx} className="text-xs text-zinc-600 dark:text-zinc-400 flex items-start space-x-3">
              <span className="p-1.5 bg-indigo-500 text-white rounded-lg flex items-center justify-center shrink-0 font-bold font-mono text-[9px] w-5 h-5">
                {idx + 1}
              </span>
              <p className="leading-relaxed">{rec}</p>
            </li>
          ))}
        </ul>
      </div>

      {/* Question-by-question inspect log */}
      <div className="space-y-4">
        <h3 className="text-base font-sans font-bold flex items-center space-x-2">
          <FileText className="w-5 h-5 text-indigo-500" />
          <span>Detailed Dialogue & Rubrics Log</span>
        </h3>

        <div className="space-y-3">
          {interview.questions.map((q, idx) => {
            const isExpanded = expandedQuestionId === q.id;
            return (
              <div 
                key={q.id}
                className="glass-panel rounded-2xl overflow-hidden"
              >
                {/* Header block click */}
                <div 
                  onClick={() => toggleExpandQuestion(q.id)}
                  className="flex items-center justify-between p-4 cursor-pointer hover:bg-white/10 dark:hover:bg-white/[0.02] transition-colors"
                >
                  <div className="flex items-center space-x-3 pr-4">
                    <span className="h-6 w-6 rounded-lg bg-white/20 dark:bg-white/[0.04] border border-zinc-200/40 dark:border-white/10 flex items-center justify-center text-[10px] font-bold shrink-0 font-mono">
                      Q{idx + 1}
                    </span>
                    <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200 line-clamp-1 leading-relaxed">
                      {q.questionText}
                    </span>
                  </div>

                  <div className="flex items-center space-x-3 shrink-0">
                    <span className="text-xs font-extrabold text-indigo-600 dark:text-indigo-400">
                      {q.evaluation ? `${q.evaluation.score}/10` : 'N/A'}
                    </span>
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-zinc-400" /> : <ChevronDown className="w-4 h-4 text-zinc-400" />}
                  </div>
                </div>

                {/* Expanded details container */}
                {isExpanded && (
                  <div className="p-5 bg-white/10 dark:bg-white/[0.01] border-t border-zinc-200/60 dark:border-white/10 space-y-4 animate-fadeIn text-xs backdrop-blur-md">
                    {/* Full question */}
                    <div className="space-y-1">
                      <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Question Asked</span>
                      <p className="text-zinc-700 dark:text-zinc-300 font-medium leading-relaxed">"{q.questionText}"</p>
                    </div>

                    {/* Answer */}
                    <div className="space-y-1 pt-2 border-t border-zinc-200/60 dark:border-white/10">
                      <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Your Answer Given</span>
                      <p className="text-zinc-600 dark:text-zinc-400 italic leading-relaxed">
                        {q.answerText ? `"${q.answerText}"` : '[No Answer/Skipped]'}
                      </p>
                    </div>

                    {/* Category Scores */}
                    {q.evaluation && (
                      <div className="space-y-3 pt-4 border-t border-zinc-200/60 dark:border-white/10">
                        <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Category Performance Matrix</span>
                        
                        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                          <div className="bg-white/20 dark:bg-white/[0.04] backdrop-blur-md p-2 rounded-xl border border-zinc-200/40 dark:border-white/10 text-center">
                            <p className="text-[9px] text-zinc-400 font-semibold">Technical Accuracy</p>
                            <p className="text-zinc-700 dark:text-zinc-200 font-bold text-sm">{q.evaluation.technicalAccuracy}/10</p>
                          </div>
                          <div className="bg-white/20 dark:bg-white/[0.04] backdrop-blur-md p-2 rounded-xl border border-zinc-200/40 dark:border-white/10 text-center">
                            <p className="text-[9px] text-zinc-400 font-semibold">Communication</p>
                            <p className="text-zinc-700 dark:text-zinc-200 font-bold text-sm">{q.evaluation.communication}/10</p>
                          </div>
                          <div className="bg-white/20 dark:bg-white/[0.04] backdrop-blur-md p-2 rounded-xl border border-zinc-200/40 dark:border-white/10 text-center">
                            <p className="text-[9px] text-zinc-400 font-semibold">Confidence Pacing</p>
                            <p className="text-zinc-700 dark:text-zinc-200 font-bold text-sm">{q.evaluation.confidence}/10</p>
                          </div>
                          <div className="bg-white/20 dark:bg-white/[0.04] backdrop-blur-md p-2 rounded-xl border border-zinc-200/40 dark:border-white/10 text-center">
                            <p className="text-[9px] text-zinc-400 font-semibold">Problem Solving</p>
                            <p className="text-zinc-700 dark:text-zinc-200 font-bold text-sm">{q.evaluation.problemSolving}/10</p>
                          </div>
                          <div className="bg-white/20 dark:bg-white/[0.04] backdrop-blur-md p-2 rounded-xl border border-zinc-200/40 dark:border-white/10 text-center">
                            <p className="text-[9px] text-zinc-400 font-semibold">Clarity Structure</p>
                            <p className="text-zinc-700 dark:text-zinc-200 font-bold text-sm">{q.evaluation.clarity}/10</p>
                          </div>
                        </div>

                        {/* Text analyses */}
                        <div className="bg-white/10 dark:bg-white/[0.02] backdrop-blur-sm p-4 rounded-xl border border-zinc-200/40 dark:border-white/10 mt-3 space-y-2">
                          <p><span className="font-bold text-zinc-700 dark:text-zinc-300">Answer Feedback:</span> {q.evaluation.feedback}</p>
                          <p className="text-indigo-600 dark:text-indigo-400"><span className="font-bold">Optimization Suggestion:</span> {q.evaluation.suggestions}</p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
