import { useTheme } from './ThemeContext.js';
import { Brain, LogOut, Sun, Moon, Sparkles, Code, FileText, BarChart3, Settings as SettingsIcon, Shield } from 'lucide-react';

interface NavbarProps {
  user: { name: string; email: string; isAdmin?: boolean } | null;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Navbar({ user, onLogout, activeTab, setActiveTab }: NavbarProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-md bg-white/45 dark:bg-white/5 border-b border-zinc-200/60 dark:border-white/10 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Brand */}
          <div 
            className="flex items-center space-x-2 cursor-pointer group"
            onClick={() => user ? setActiveTab('dashboard') : setActiveTab('landing')}
          >
            <div className="p-2 bg-gradient-to-tr from-indigo-500 to-emerald-400 rounded-xl text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform duration-200">
              <Brain className="w-5 h-5" id="brand-logo" />
            </div>
            <span className="font-sans font-bold text-lg bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-600 dark:from-white dark:via-white dark:to-slate-300 bg-clip-text text-transparent tracking-tight">
              Interviewer.ai
            </span>
            <Sparkles className="w-4 h-4 text-emerald-400 animate-pulse" />
          </div>

          {/* Navigation Links - Centered (Only if user is logged in) */}
          {user && (
            <div className="hidden md:flex items-center space-x-2">
              <button
                id="nav-dashboard"
                onClick={() => setActiveTab('dashboard')}
                className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-200 border ${
                  activeTab === 'dashboard' || activeTab.startsWith('interview') || activeTab === 'report'
                    ? 'bg-indigo-500/10 border-indigo-500/25 text-indigo-600 dark:text-indigo-400'
                    : 'border-transparent text-zinc-600 dark:text-slate-400 hover:bg-white/10 dark:hover:bg-white/5 hover:text-zinc-950 dark:hover:text-white'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Practice Suite</span>
              </button>

              <button
                id="nav-resume"
                onClick={() => setActiveTab('resume')}
                className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-200 border ${
                  activeTab === 'resume'
                    ? 'bg-indigo-500/10 border-indigo-500/25 text-indigo-600 dark:text-indigo-400'
                    : 'border-transparent text-zinc-600 dark:text-slate-400 hover:bg-white/10 dark:hover:bg-white/5 hover:text-zinc-950 dark:hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Resume Analysis</span>
              </button>

              <button
                id="nav-coding"
                onClick={() => setActiveTab('coding')}
                className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-200 border ${
                  activeTab === 'coding'
                    ? 'bg-indigo-500/10 border-indigo-500/25 text-indigo-600 dark:text-indigo-400'
                    : 'border-transparent text-zinc-600 dark:text-slate-400 hover:bg-white/10 dark:hover:bg-white/5 hover:text-zinc-950 dark:hover:text-white'
                }`}
              >
                <Code className="w-3.5 h-3.5" />
                <span>Coding Round</span>
              </button>

              {user.isAdmin && (
                <button
                  id="nav-admin"
                  onClick={() => setActiveTab('admin')}
                  className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-200 border ${
                    activeTab === 'admin'
                      ? 'bg-rose-500/10 border-rose-500/25 text-rose-600 dark:text-rose-400 font-semibold'
                      : 'border-transparent text-zinc-600 dark:text-slate-400 hover:bg-white/10 dark:hover:bg-white/5 hover:text-zinc-950 dark:hover:text-white'
                  }`}
                >
                  <Shield className="w-3.5 h-3.5" />
                  <span>Admin</span>
                </button>
              )}
            </div>
          )}

          {/* Settings, Theme & Auth Controls */}
          <div className="flex items-center space-x-3">
            {/* Theme Toggle */}
            <button
              id="theme-toggle"
              onClick={toggleTheme}
              className="p-2 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-900 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-all duration-200"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>

            {user ? (
              <>
                {/* User Settings Icon */}
                <button
                  id="nav-settings"
                  onClick={() => setActiveTab('settings')}
                  className={`p-2 rounded-xl border transition-all duration-200 ${
                    activeTab === 'settings'
                      ? 'border-indigo-500/30 bg-indigo-50/50 dark:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400'
                      : 'border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-900 text-zinc-600 dark:text-zinc-400'
                  }`}
                  aria-label="Settings"
                >
                  <SettingsIcon className="w-4 h-4" />
                </button>

                {/* Profile Badge & Logout (Desktop) */}
                <div className="hidden md:flex items-center space-x-3 pl-2 border-l border-zinc-200 dark:border-zinc-800">
                  <div className="flex flex-col text-right">
                    <span className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">{user.name}</span>
                    <span className="text-[10px] text-zinc-500">{user.isAdmin ? 'Administrator' : 'Premium Member'}</span>
                  </div>
                  <button
                    id="btn-logout"
                    onClick={onLogout}
                    className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/20 text-zinc-500 hover:text-red-500 transition-all duration-200"
                    title="Log Out"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>

                {/* Quick Menu Button (Mobile) */}
                <button
                  id="btn-logout-mobile"
                  onClick={onLogout}
                  className="md:hidden p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/20 text-zinc-500 hover:text-red-500 transition-all duration-200"
                  title="Log Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  id="btn-login-nav"
                  onClick={() => setActiveTab('login')}
                  className="text-sm font-medium text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white px-3 py-1.5 transition-colors duration-200"
                >
                  Log In
                </button>
                <button
                  id="btn-signup-nav"
                  onClick={() => setActiveTab('signup')}
                  className="text-sm font-medium bg-gradient-to-r from-indigo-500 to-violet-600 text-white shadow-sm hover:shadow-md px-4 py-2 rounded-xl transition-all duration-200 hover:-translate-y-0.5"
                >
                  Get Started
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Navigation Rail */}
        {user && (
          <div className="md:hidden flex items-center justify-around py-2 border-t border-zinc-100 dark:border-zinc-900">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex flex-col items-center p-1.5 transition-colors ${
                activeTab === 'dashboard' ? 'text-indigo-600 dark:text-indigo-400' : 'text-zinc-500'
              }`}
            >
              <BarChart3 className="w-4.5 h-4.5" />
              <span className="text-[10px] mt-0.5">Practice</span>
            </button>
            <button
              onClick={() => setActiveTab('resume')}
              className={`flex flex-col items-center p-1.5 transition-colors ${
                activeTab === 'resume' ? 'text-indigo-600 dark:text-indigo-400' : 'text-zinc-500'
              }`}
            >
              <FileText className="w-4.5 h-4.5" />
              <span className="text-[10px] mt-0.5">Resume</span>
            </button>
            <button
              onClick={() => setActiveTab('coding')}
              className={`flex flex-col items-center p-1.5 transition-colors ${
                activeTab === 'coding' ? 'text-indigo-600 dark:text-indigo-400' : 'text-zinc-500'
              }`}
            >
              <Code className="w-4.5 h-4.5" />
              <span className="text-[10px] mt-0.5">Coding</span>
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`flex flex-col items-center p-1.5 transition-colors ${
                activeTab === 'settings' ? 'text-indigo-600 dark:text-indigo-400' : 'text-zinc-500'
              }`}
            >
              <SettingsIcon className="w-4.5 h-4.5" />
              <span className="text-[10px] mt-0.5">Settings</span>
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
