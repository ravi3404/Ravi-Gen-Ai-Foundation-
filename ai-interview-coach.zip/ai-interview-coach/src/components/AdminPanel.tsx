import React, { useEffect, useState } from 'react';
import { useTheme } from './ThemeContext.js';
import { 
  Users, 
  Activity, 
  CheckCircle, 
  Award, 
  Shield, 
  HelpCircle,
  Briefcase,
  Layers,
  ChevronRight,
  TrendingUp,
  RefreshCw,
  Clock
} from 'lucide-react';

interface AdminPanelProps {
  authToken: string;
}

export default function AdminPanel({ authToken }: AdminPanelProps) {
  const { theme } = useTheme();
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchAdminStats = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/admin/stats', {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      const data = await res.json();
      if (res.ok) {
        setStats(data);
      } else {
        console.error('Failed to load admin telemetry:', data.error);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminStats();
  }, [authToken]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-4rem)] text-zinc-500">
        <RefreshCw className="w-8 h-8 animate-spin text-red-500 mb-4" />
        <span className="text-xs font-semibold">Retrieving Site Telemetry...</span>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="text-center py-12 max-w-sm mx-auto space-y-4 text-zinc-500">
        <Shield className="w-10 h-10 text-red-500 mx-auto" />
        <h3 className="font-bold text-base">Telemetry Offline</h3>
        <p className="text-xs text-zinc-400">An error occurred retrieving database entries. Please verify session administrator privileges.</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-zinc-900 dark:text-zinc-100 transition-colors duration-300">
      
      {/* Title block */}
      <div>
        <span className="text-[10px] font-bold uppercase tracking-wider text-red-500 dark:text-red-400 flex items-center space-x-1">
          <Shield className="w-3.5 h-3.5" />
          <span>System Administration Dashboard</span>
        </span>
        <h1 className="text-2xl font-sans font-extrabold tracking-tight">Active Usage & Platform Metrics</h1>
        <p className="text-xs text-zinc-500 mt-1">
          Observe system-wide user counts, active simulated mock volumes, preparation scores distribution, and platform telemetry logs.
        </p>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-zinc-900/40 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-semibold uppercase">Total Users</span>
            <Users className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="mt-2">
            <span className="text-2xl font-extrabold">{stats.totalUsers}</span>
            <span className="text-[10px] text-zinc-500 block mt-0.5">Active candidates registered</span>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900/40 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-semibold uppercase">Total Mocks Runs</span>
            <Activity className="w-4 h-4 text-violet-500" />
          </div>
          <div className="mt-2">
            <span className="text-2xl font-extrabold">{stats.totalInterviews}</span>
            <span className="text-[10px] text-zinc-500 block mt-0.5">Overall interviews simulated</span>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900/40 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-semibold uppercase">Completed Logs</span>
            <CheckCircle className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-2">
            <span className="text-2xl font-extrabold">{stats.completedInterviews}</span>
            <span className="text-[10px] text-zinc-500 block mt-0.5">Mock rounds completed</span>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900/40 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-semibold uppercase">Global Avg Score</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2">
            <span className="text-2xl font-extrabold">{stats.averageInterviewScore}%</span>
            <span className="text-[10px] text-zinc-500 block mt-0.5">Aggregated mock evaluation score</span>
          </div>
        </div>
      </div>

      {/* Grid of charts & ratios */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Role Distribution */}
        <div className="bg-white dark:bg-zinc-900/40 p-6 rounded-3xl border border-zinc-200 dark:border-zinc-800">
          <h3 className="text-xs font-extrabold flex items-center space-x-2 border-b border-zinc-100 dark:border-zinc-800 pb-3 mb-4 uppercase text-zinc-500">
            <Briefcase className="w-4 h-4" />
            <span>Target Roles Frequency Map</span>
          </h3>

          <div className="space-y-3.5">
            {Object.keys(stats.roleDistribution).length === 0 ? (
              <p className="text-center text-xs text-zinc-500 py-6">No data registered yet.</p>
            ) : (
              Object.entries(stats.roleDistribution).map(([role, count]: any) => (
                <div key={role} className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span>{role}</span>
                    <span className="text-zinc-500">{count} runs</span>
                  </div>
                  <div className="h-1.5 w-full bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-indigo-500 to-violet-500" 
                      style={{ width: `${Math.min((count / Math.max(stats.totalInterviews, 1)) * 100, 100)}%` }} 
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Type distribution */}
        <div className="bg-white dark:bg-zinc-900/40 p-6 rounded-3xl border border-zinc-200 dark:border-zinc-800">
          <h3 className="text-xs font-extrabold flex items-center space-x-2 border-b border-zinc-100 dark:border-zinc-800 pb-3 mb-4 uppercase text-zinc-500">
            <Layers className="w-4 h-4" />
            <span>Mock Focus Distributions</span>
          </h3>

          <div className="space-y-3.5">
            {Object.keys(stats.typeDistribution).length === 0 ? (
              <p className="text-center text-xs text-zinc-500 py-6">No data registered yet.</p>
            ) : (
              Object.entries(stats.typeDistribution).map(([type, count]: any) => (
                <div key={type} className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span>{type} focus</span>
                    <span className="text-zinc-500">{count} runs</span>
                  </div>
                  <div className="h-1.5 w-full bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-pink-500 to-rose-500" 
                      style={{ width: `${Math.min((count / Math.max(stats.totalInterviews, 1)) * 100, 100)}%` }} 
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recent candidates registration table */}
      <div className="bg-white dark:bg-zinc-900/40 rounded-3xl border border-zinc-200 dark:border-zinc-800 p-6 space-y-4">
        <h3 className="text-xs font-extrabold flex items-center space-x-2 border-b border-zinc-100 dark:border-zinc-800 pb-3 mb-2 uppercase text-zinc-500">
          <Users className="w-4 h-4" />
          <span>Recently Registered Students</span>
        </h3>

        <div className="overflow-x-auto text-xs">
          <table className="w-full text-left">
            <thead>
              <tr className="text-zinc-400 font-semibold border-b border-zinc-100 dark:border-zinc-800/80 pb-2">
                <th className="py-2">User ID</th>
                <th className="py-2">Student Name</th>
                <th className="py-2">Email Address</th>
                <th className="py-2 text-right">Registration Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
              {stats.recentUsers.map((u: any) => (
                <tr key={u.id} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/40">
                  <td className="py-3 font-mono text-[10px] text-zinc-400">{u.id}</td>
                  <td className="py-3 font-bold">{u.name}</td>
                  <td className="py-3 text-zinc-500">{u.email}</td>
                  <td className="py-3 text-right text-zinc-400">
                    {new Date(u.createdAt).toLocaleDateString()} {new Date(u.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
