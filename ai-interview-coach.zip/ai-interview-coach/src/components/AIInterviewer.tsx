import React, { useState, useEffect, useRef } from 'react';
import { useTheme } from './ThemeContext.js';
import { 
  Mic, 
  Square, 
  Send, 
  Volume2, 
  VolumeX, 
  ChevronRight, 
  Clock, 
  Award, 
  CheckCircle, 
  MessageSquare,
  Sparkles,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { Interview, InterviewQuestion, AnswerEvaluation } from '../types.js';

interface AIInterviewerProps {
  interviewId: string;
  authToken: string;
  onInterviewComplete: (interviewId: string) => void;
  onExit: () => void;
}

export default function AIInterviewer({ 
  interviewId, 
  authToken, 
  onInterviewComplete, 
  onExit 
}: AIInterviewerProps) {
  const { theme } = useTheme();
  
  const [interview, setInterview] = useState<Interview | null>(null);
  const [activeQuestionIndex, setActiveQuestionIndex] = useState(0);
  const [answerText, setAnswerText] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  
  // Real-time evaluation of previous answered question
  const [lastEvaluation, setLastEvaluation] = useState<AnswerEvaluation | null>(null);
  const [showEvaluationPane, setShowEvaluationPane] = useState(false);

  // Audio Recording states
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [transcribing, setTranscribing] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  
  // Text to Speech states
  const [isPlayingTTS, setIsPlayingTTS] = useState(false);
  const [autoplayTTS, setAutoplayTTS] = useState(true);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Load the current interview
  const fetchInterview = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/interviews/${interviewId}`, {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setInterview(data.interview);
        
        // Find current question index
        const qs = data.interview.questions || [];
        const currentIdx = qs.findIndex((q: any) => q.answerText === undefined);
        const resolvedIdx = currentIdx === -1 ? qs.length - 1 : currentIdx;
        setActiveQuestionIndex(resolvedIdx);

        // If interview is already completed, redirect immediately
        if (data.interview.status === 'completed') {
          onInterviewComplete(interviewId);
        }
      } else {
        console.error('Failed to load interview metadata.');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInterview();
    return () => {
      stopRecordingTimer();
    };
  }, [interviewId]);

  // Autoplay TTS on new question loaded
  useEffect(() => {
    if (interview && autoplayTTS && !loading) {
      const qs = interview.questions || [];
      const currentQ = qs[activeQuestionIndex];
      if (currentQ && currentQ.answerText === undefined && !submitting) {
        // Delay slightly for smooth transitions
        const t = setTimeout(() => {
          playQuestionTTS(activeQuestionIndex);
        }, 1200);
        return () => clearTimeout(t);
      }
    }
  }, [activeQuestionIndex, interview?.id, loading]);

  // TTS Fetch & Play helper
  const playQuestionTTS = async (index: number) => {
    if (isPlayingTTS) return;
    setIsPlayingTTS(true);
    try {
      const res = await fetch(`/api/interviews/${interviewId}/tts/${index}`, {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      if (!res.ok) throw new Error('TTS audio generation failed');
      const blob = await res.blob();
      const audioUrl = URL.createObjectURL(blob);
      const audio = new Audio(audioUrl);
      audio.onended = () => setIsPlayingTTS(false);
      await audio.play();
    } catch (err) {
      console.error('Failed to vocalize text:', err);
      setIsPlayingTTS(false);
    }
  };

  // Recording timer control
  const startRecordingTimer = () => {
    setRecordingSeconds(0);
    timerRef.current = setInterval(() => {
      setRecordingSeconds(prev => prev + 1);
    }, 1000);
  };

  const stopRecordingTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  // Microphone recording functions
  const handleStartRecording = async () => {
    audioChunksRef.current = [];
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorderRef.current = mediaRecorder;
      
      mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
        await handleTranscribe(blob);
      };

      mediaRecorder.start();
      setIsRecording(true);
      startRecordingTimer();
    } catch (err) {
      console.error('Microphone hardware access denied:', err);
      alert('Could not access microphone. Please verify frame permissions in settings.');
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      stopRecordingTimer();
    }
  };

  // Transcribe audio using Whisper
  const handleTranscribe = async (blob: Blob) => {
    setTranscribing(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = async () => {
        const base64data = (reader.result as string).split(',')[1];
        
        const res = await fetch('/api/interviews/transcribe', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
          },
          body: JSON.stringify({ audioBase64: base64data })
        });
        
        const data = await res.json();
        if (res.ok && data.text) {
          setAnswerText(prev => (prev ? prev + ' ' + data.text : data.text));
        } else {
          throw new Error(data.error || 'Failed to transcribe.');
        }
      };
    } catch (err: any) {
      console.error('Whisper transcription error:', err);
      alert(err.message || 'Speech conversion failed. Please try typing your answer.');
    } finally {
      setTranscribing(false);
    }
  };

  // Submit Answer Text
  const handleSubmitAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!answerText.trim()) return;

    setSubmitting(true);
    setLastEvaluation(null);
    setShowEvaluationPane(false);

    try {
      const res = await fetch(`/api/interviews/${interviewId}/answer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({ answerText })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Answer submission failed.');

      // Check current state after update
      const updatedInterview: Interview = data.interview;
      setInterview(updatedInterview);
      setAnswerText('');

      // Find the evaluation that was just generated
      const previousQs = updatedInterview.questions;
      const evaluatedQ = previousQs[activeQuestionIndex];
      
      if (evaluatedQ && evaluatedQ.evaluation) {
        setLastEvaluation(evaluatedQ.evaluation);
        setShowEvaluationPane(true);
      }

      if (updatedInterview.status === 'completed') {
        // Let user see evaluation of the final question before continuing to final report
        // Handled in UI by clicking "View Final Report" instead of "Next Question"
      } else {
        // Active index will be next item once user clicks "Continue"
      }
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Error processing response.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleNextQuestion = () => {
    setShowEvaluationPane(false);
    setLastEvaluation(null);
    setActiveQuestionIndex(prev => prev + 1);
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-4rem)] bg-zinc-50 dark:bg-zinc-950 text-zinc-500">
        <RefreshCw className="w-8 h-8 animate-spin text-indigo-500 mb-4" />
        <span className="text-sm font-semibold">Configuring AI Boardroom...</span>
      </div>
    );
  }

  if (!interview) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-4rem)] p-4 text-center">
        <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
        <h3 className="font-bold text-lg">Interview Session Not Found</h3>
        <p className="text-xs text-zinc-500 max-w-sm mt-2">The requested practice session could not be retrieved from persistence.</p>
        <button onClick={onExit} className="mt-6 px-4 py-2 bg-zinc-900 text-white rounded-xl text-xs font-semibold">
          Return to Practice Suite
        </button>
      </div>
    );
  }

  const activeQuestion: InterviewQuestion = interview.questions[activeQuestionIndex] || {};
  const currentNum = activeQuestionIndex + 1;
  const targetNum = interview.duration <= 5 ? 3 : interview.duration <= 10 ? 5 : interview.duration <= 15 ? 8 : 12;
  const percentComplete = Math.round(((currentNum - 1) / targetNum) * 100);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 text-zinc-900 dark:text-zinc-100 transition-colors duration-300">
      
      {/* Top Header Rail */}
      <div className="flex items-center justify-between border-b border-zinc-200 dark:border-zinc-800 pb-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
            {interview.interviewType} Practice Session
          </span>
          <h1 className="text-lg font-extrabold flex items-center space-x-2">
            <span>{interview.jobRole}</span>
            <span className="text-zinc-400 font-normal text-xs">({interview.experienceLevel})</span>
          </h1>
        </div>

        <div className="flex items-center space-x-4 text-xs font-semibold text-zinc-500">
          <button
            onClick={() => setAutoplayTTS(!autoplayTTS)}
            className={`p-2 rounded-xl border transition-colors ${
              autoplayTTS 
                ? 'border-indigo-500/20 bg-indigo-50/50 dark:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400' 
                : 'border-zinc-200 dark:border-zinc-800'
            }`}
            title="Toggle Question Autoplay"
          >
            {autoplayTTS ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={onExit}
            className="px-3 py-2 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-900 font-bold transition text-xs"
          >
            Quit Practice
          </button>
        </div>
      </div>

      {/* Main split-screen panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left pane: AI Interviewer persona and status */}
        <div className="lg:col-span-4 glass-panel p-6 rounded-3xl space-y-6 text-center">
          {/* Avatar visual */}
          <div className="relative w-24 h-24 mx-auto">
            <div className={`absolute inset-0 bg-gradient-to-tr from-indigo-500 to-emerald-500 rounded-full animate-pulse opacity-40 blur-lg ${isRecording ? 'scale-110 bg-red-500' : ''}`} />
            <div className="relative w-24 h-24 rounded-full bg-slate-950 border-2 border-indigo-500 flex items-center justify-center overflow-hidden shadow-inner">
              <span className="text-4xl font-sans font-extrabold text-white">AI</span>
              {isPlayingTTS && (
                <div className="absolute inset-x-0 bottom-1 flex justify-center items-center space-x-0.5">
                  <span className="w-1.5 h-3 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                  <span className="w-1.5 h-5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                  <span className="w-1.5 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }} />
                </div>
              )}
            </div>
          </div>

          <div>
            <h3 className="font-sans font-bold text-base">Boardroom Panelist Coach</h3>
            <span className="text-[10px] text-zinc-400 uppercase tracking-wide">GPT-4o Powered Persona</span>
          </div>

          {/* Interactive Progress Ring / Bar */}
          <div className="space-y-2 text-left pt-2 border-t border-zinc-200/60 dark:border-white/10">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-zinc-500">Practice Completion</span>
              <span>{percentComplete}%</span>
            </div>
            <div className="h-2 w-full bg-zinc-200 dark:bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-indigo-500 to-emerald-500 transition-all duration-300" style={{ width: `${percentComplete}%` }} />
            </div>
            <div className="flex justify-between text-[10px] text-zinc-400">
              <span>Question {currentNum} of {targetNum}</span>
              <span>Duration Target: {interview.duration} mins</span>
            </div>
          </div>

          {/* Prompt Guidelines helpers depending on interview type */}
          <div className="text-left bg-white/20 dark:bg-white/[0.02] p-4 rounded-2xl border border-zinc-200/60 dark:border-white/5 space-y-2 backdrop-blur-sm">
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Training Recommendations</span>
            {interview.interviewType === 'Technical' ? (
              <p className="text-[10px] text-zinc-500 dark:text-slate-400 leading-relaxed">State your complexity. Outline algorithmic space bounds and explain custom edge assumptions clearly.</p>
            ) : interview.interviewType === 'Behavioral' ? (
              <p className="text-[10px] text-zinc-500 dark:text-slate-400 leading-relaxed">Structure your narrative using the STAR methodology (Situation, Task, Action, Result). Quantify outputs.</p>
            ) : (
              <p className="text-[10px] text-zinc-500 dark:text-slate-400 leading-relaxed">Convey structure and clear frameworks. Maintain an eye-to-eye communicative confidence pacing.</p>
            )}
          </div>
        </div>

        {/* Right pane: Dynamic Q&A Chat Frame */}
        <div className="lg:col-span-8 glass-panel rounded-3xl p-6 sm:p-8 space-y-6 flex flex-col justify-between min-h-[400px]">
          
          {/* Active Question Panel */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-200/60 dark:border-white/10 pb-3">
              <span className="text-xs font-semibold text-zinc-500">AI Coach Question</span>
              <button
                id="btn-play-tts-question"
                onClick={() => playQuestionTTS(activeQuestionIndex)}
                disabled={isPlayingTTS}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-zinc-200/60 dark:border-white/10 text-xs font-semibold hover:bg-white/10 dark:hover:bg-white/[0.03] text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 disabled:opacity-50"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>{isPlayingTTS ? 'Playing Vocal...' : 'Speak Question'}</span>
              </button>
            </div>

            <div className="p-5 rounded-2xl bg-indigo-500/5 border border-indigo-500/10 text-base sm:text-lg font-sans font-medium text-zinc-800 dark:text-zinc-200 leading-relaxed">
              "{activeQuestion.questionText}"
            </div>
          </div>

          {/* Real-time score sliding element (only shown when question has just been evaluated) */}
          {showEvaluationPane && lastEvaluation && (
            <div className="bg-emerald-500/5 border border-emerald-500/10 p-5 rounded-2xl space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between border-b border-emerald-500/10 pb-2">
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center space-x-1.5">
                  <CheckCircle className="w-4 h-4" />
                  <span>Real-Time Answer Rubric</span>
                </span>
                <span className="text-xs text-zinc-500">Dynamic GPT-4o Metrics</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div className="bg-white/20 dark:bg-white/[0.04] backdrop-blur-md p-2.5 rounded-xl border border-zinc-200/40 dark:border-white/10 text-center">
                  <p className="text-[9px] text-zinc-400 font-semibold uppercase">Overall</p>
                  <p className="text-emerald-500 font-extrabold text-lg">{lastEvaluation.score}/10</p>
                </div>
                <div className="bg-white/20 dark:bg-white/[0.04] backdrop-blur-md p-2.5 rounded-xl border border-zinc-200/40 dark:border-white/10 text-center">
                  <p className="text-[9px] text-zinc-400 font-semibold uppercase">Accuracy</p>
                  <p className="text-zinc-700 dark:text-zinc-200 font-extrabold text-sm">{lastEvaluation.technicalAccuracy}/10</p>
                </div>
                <div className="bg-white/20 dark:bg-white/[0.04] backdrop-blur-md p-2.5 rounded-xl border border-zinc-200/40 dark:border-white/10 text-center">
                  <p className="text-[9px] text-zinc-400 font-semibold uppercase">Comm.</p>
                  <p className="text-zinc-700 dark:text-zinc-200 font-extrabold text-sm">{lastEvaluation.communication}/10</p>
                </div>
                <div className="bg-white/20 dark:bg-white/[0.04] backdrop-blur-md p-2.5 rounded-xl border border-zinc-200/40 dark:border-white/10 text-center">
                  <p className="text-[9px] text-zinc-400 font-semibold uppercase">Confidence</p>
                  <p className="text-zinc-700 dark:text-zinc-200 font-extrabold text-sm">{lastEvaluation.confidence}/10</p>
                </div>
                <div className="bg-white/20 dark:bg-white/[0.04] backdrop-blur-md p-2.5 rounded-xl border border-zinc-200/40 dark:border-white/10 text-center">
                  <p className="text-[9px] text-zinc-400 font-semibold uppercase">Solving</p>
                  <p className="text-zinc-700 dark:text-zinc-200 font-extrabold text-sm">{lastEvaluation.problemSolving}/10</p>
                </div>
              </div>

              <div className="text-xs space-y-1 text-zinc-600 dark:text-zinc-400 leading-relaxed bg-white/10 dark:bg-white/[0.02] backdrop-blur-md p-3.5 rounded-xl border border-zinc-200/40 dark:border-white/5">
                <p><span className="font-bold text-zinc-700 dark:text-zinc-300">Feedback:</span> {lastEvaluation.feedback}</p>
                <p className="mt-2 text-emerald-600 dark:text-emerald-400"><span className="font-bold">Next Steps Improvement:</span> {lastEvaluation.suggestions}</p>
              </div>

              {/* Action path forward */}
              <div className="flex justify-end pt-2">
                {interview.status === 'completed' ? (
                  <button
                    id="btn-go-to-report"
                    onClick={() => onInterviewComplete(interviewId)}
                    className="flex items-center space-x-1.5 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-emerald-500 text-white text-xs font-semibold shadow-md transition"
                  >
                    <span>View Overall Hiring Report</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    id="btn-next-question"
                    onClick={handleNextQuestion}
                    className="flex items-center space-x-1.5 px-5 py-2.5 rounded-xl bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-xs font-semibold transition"
                  >
                    <span>Continue to Next Question</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Active input pane (only shown when waiting for current answer) */}
          {!showEvaluationPane && (
            <form onSubmit={handleSubmitAnswer} className="space-y-4 pt-6 border-t border-zinc-200/60 dark:border-white/10">
              
              {/* Media input controls */}
              <div className="flex items-center justify-between pb-1">
                <span className="text-xs font-semibold text-zinc-500">Your Answer Workspace</span>
                
                {isRecording ? (
                  <button
                    id="btn-stop-recording"
                    type="button"
                    onClick={handleStopRecording}
                    className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-red-500 animate-pulse text-white text-xs font-semibold"
                  >
                    <Square className="w-3.5 h-3.5" />
                    <span>Stop Recording ({recordingSeconds}s)</span>
                  </button>
                ) : (
                  <button
                    id="btn-start-recording"
                    type="button"
                    onClick={handleStartRecording}
                    disabled={submitting || transcribing}
                    className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg border border-zinc-200/60 dark:border-white/10 hover:bg-white/10 dark:hover:bg-white/[0.03] text-zinc-600 dark:text-zinc-400 text-xs font-semibold transition backdrop-blur-sm"
                  >
                    <Mic className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Answer verbally (Whisper STT)</span>
                  </button>
                )}
              </div>

              {/* Textarea */}
              <div className="relative">
                <textarea
                  id="interviewer-answer-input"
                  rows={6}
                  value={answerText}
                  onChange={(e) => setAnswerText(e.target.value)}
                  placeholder="Type your answer in detail here, or click the mic button above to answer verbally..."
                  disabled={submitting || transcribing}
                  className="w-full px-4 py-3 rounded-2xl border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] backdrop-blur-md focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500/60 text-sm text-zinc-900 dark:text-white transition-all disabled:opacity-55"
                />
                
                {transcribing && (
                  <div className="absolute inset-0 bg-white/50 dark:bg-zinc-950/50 backdrop-blur-md flex items-center justify-center rounded-2xl">
                    <span className="animate-spin border-2 border-indigo-500 border-t-transparent rounded-full w-4 h-4 mr-2" />
                    <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">Whisper transcribing speech...</span>
                  </div>
                )}
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-between pt-2">
                <span className="text-[10px] text-zinc-400 italic">Provide structured answers for higher accuracy grading.</span>
                
                <button
                  id="btn-submit-answer-text"
                  type="submit"
                  disabled={submitting || !answerText.trim()}
                  className="flex items-center space-x-2 px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-emerald-500 hover:opacity-90 text-white font-semibold text-xs shadow-md shadow-indigo-500/10 disabled:opacity-50 transition-all cursor-pointer"
                >
                  {submitting ? (
                    <>
                      <span className="animate-spin border-2 border-white/20 border-t-white rounded-full w-3.5 h-3.5 mr-1" />
                      <span>AI Evaluator processing...</span>
                    </>
                  ) : (
                    <>
                      <span>Submit Answer</span>
                      <Send className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

        </div>
      </div>
    </div>
  );
}
