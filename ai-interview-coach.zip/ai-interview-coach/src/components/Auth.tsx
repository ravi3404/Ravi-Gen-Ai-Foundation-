import React, { useState } from 'react';
import { useTheme } from './ThemeContext.js';
import { motion } from 'motion/react';
import { Mail, Lock, User as UserIcon, Shield, Sparkles, Brain, CheckCircle2 } from 'lucide-react';

interface AuthProps {
  initialMode: 'login' | 'signup';
  onAuthSuccess: (user: { id: string; name: string; email: string; isAdmin?: boolean }, token: string) => void;
  onSwitchMode: (mode: 'login' | 'signup') => void;
}

export default function Auth({ initialMode, onAuthSuccess, onSwitchMode }: AuthProps) {
  const { theme } = useTheme();
  const [isLogin, setIsLogin] = useState(initialMode === 'login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Sync mode if changed from prop
  React.useEffect(() => {
    setIsLogin(initialMode === 'login');
    setError(null);
  }, [initialMode]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const url = isLogin ? '/api/auth/login' : '/api/auth/signup';
    const body = isLogin ? { email, password } : { name, email, password };

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed');
      }

      onAuthSuccess(data.user, data.token);
    } catch (err: any) {
      setError(err.message || 'Server connection failed. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-zinc-50 dark:bg-zinc-950 p-4 transition-colors duration-300">
      <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-indigo-500/10 dark:bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-violet-500/10 dark:bg-violet-500/5 rounded-full blur-3xl pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md glass-panel p-8 rounded-3xl shadow-2xl relative overflow-hidden"
      >
        <div className="text-center mb-8">
          <div className="inline-flex p-3 bg-gradient-to-tr from-indigo-500 to-violet-600 rounded-2xl text-white shadow-lg mb-4">
            <Brain className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-sans font-bold tracking-tight text-zinc-900 dark:text-white">
            {isLogin ? 'Welcome Back Officer' : 'Create Coach Account'}
          </h2>
          <p className="mt-2 text-xs text-zinc-500 dark:text-zinc-400">
            {isLogin ? 'Access your interview suites and training logs' : 'Sign up to practice technical algorithms and behavioral questions'}
          </p>
        </div>

        {error && (
          <div className="mb-6 p-3.5 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 text-red-600 dark:text-red-400 text-xs rounded-xl flex items-start space-x-2">
            <span className="font-bold">Error:</span>
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-zinc-600 dark:text-zinc-400">Full Name</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-zinc-400">
                  <UserIcon className="w-4 h-4" />
                </span>
                <input
                  id="auth-name-input"
                  type="text"
                  required
                  placeholder="e.g. Alex Rivera"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl text-sm border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] hover:bg-white/30 dark:hover:bg-white/[0.05] focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-zinc-900 dark:text-white transition-all"
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-zinc-600 dark:text-zinc-400">Email Address</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-zinc-400">
                <Mail className="w-4 h-4" />
              </span>
              <input
                id="auth-email-input"
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-xl text-sm border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] hover:bg-white/30 dark:hover:bg-white/[0.05] focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-zinc-900 dark:text-white transition-all"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-zinc-600 dark:text-zinc-400">Password</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-zinc-400">
                <Lock className="w-4 h-4" />
              </span>
              <input
                id="auth-password-input"
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-xl text-sm border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] hover:bg-white/30 dark:hover:bg-white/[0.05] focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-zinc-900 dark:text-white transition-all"
              />
            </div>
          </div>

          <button
            id="auth-submit-btn"
            type="submit"
            disabled={loading}
            className="w-full py-3.5 mt-2 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-indigo-500 to-violet-600 shadow-lg shadow-indigo-500/20 hover:shadow-indigo-500/35 hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 disabled:pointer-events-none transition-all duration-200 cursor-pointer"
          >
            {loading ? 'Authenticating...' : isLogin ? 'Log In' : 'Sign Up'}
          </button>
        </form>

        <div className="mt-6 text-center border-t border-zinc-100 dark:border-zinc-800/80 pt-5">
          <button
            id="auth-toggle-mode-btn"
            onClick={() => {
              setIsLogin(!isLogin);
              onSwitchMode(isLogin ? 'signup' : 'login');
              setError(null);
            }}
            className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold hover:underline cursor-pointer"
          >
            {isLogin ? "Don't have an account? Sign up" : 'Already have an account? Log in'}
          </button>
        </div>

        {/* Dynamic features helper bottom */}
        <div className="mt-5 flex items-center justify-center space-x-1.5 text-[10px] text-zinc-400">
          <Shield className="w-3.5 h-3.5 text-emerald-500" />
          <span>Secured with file-backed SQLite emulation</span>
        </div>
      </motion.div>
    </div>
  );
}
