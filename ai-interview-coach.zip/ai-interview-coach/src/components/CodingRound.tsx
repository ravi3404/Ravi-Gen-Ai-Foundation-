import React, { useState } from 'react';
import { useTheme } from './ThemeContext.js';
import { 
  Code, 
  Terminal, 
  Play, 
  CheckCircle, 
  AlertCircle, 
  Zap, 
  ArrowRight,
  Sparkles,
  Award,
  RefreshCw
} from 'lucide-react';
import { CodingChallenge, CodeReview } from '../types.js';

interface CodingRoundProps {
  authToken: string;
}

export default function CodingRound({ authToken }: CodingRoundProps) {
  const { theme } = useTheme();
  
  const [topic, setTopic] = useState('Arrays & Hashing');
  const [difficulty, setDifficulty] = useState<'Junior' | 'Mid-Level' | 'Senior'>('Mid-Level');
  const [challenge, setChallenge] = useState<CodingChallenge | null>(null);
  const [code, setCode] = useState('');
  const [generating, setGenerating] = useState(false);
  
  const [review, setReview] = useState<CodeReview | null>(null);
  const [evaluating, setEvaluating] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenerating(true);
    setReview(null);
    try {
      const res = await fetch('/api/coding/challenge', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({ topic, experienceLevel: difficulty })
      });
      const data = await res.json();
      if (res.ok && data.challenge) {
        setChallenge(data.challenge);
        setCode(data.challenge.starterCode || '');
      } else {
        throw new Error(data.error || 'Challenge compilation failed');
      }
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Error occurred generating algorithmic challenge.');
    } finally {
      setGenerating(false);
    }
  };

  const handleEvaluate = async () => {
    if (!challenge || !code.trim()) return;

    setEvaluating(true);
    try {
      const res = await fetch('/api/coding/evaluate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          challengeTitle: challenge.title,
          challengeDescription: challenge.description,
          codeText: code,
          language: challenge.language || 'javascript'
        })
      });
      const data = await res.json();
      if (res.ok && data.review) {
        setReview(data.review);
      } else {
        throw new Error(data.error || 'Code assessment failed.');
      }
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Error reviewing code entry.');
    } finally {
      setEvaluating(false);
    }
  };

  const topics = [
    'Arrays & Hashing',
    'Two Pointers & Sliding Window',
    'Trees & Depth First Search',
    'Stack & Queue Structures',
    'Dynamic Programming',
    'Graph Algorithms',
    'System Design Schemas'
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-zinc-900 dark:text-zinc-100 transition-colors duration-300">
      
      {/* Header Title */}
      <div>
        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
          OpenAI Whiteboard Simulator
        </span>
        <h1 className="text-2xl font-sans font-extrabold tracking-tight">Algorithmic Coding Round</h1>
        <p className="text-xs text-zinc-500 mt-1">
          Simulate a developer whiteboard round. Write correct logic blocks and let GPT-4o analyze time/space bounds, syntax flaws, and optimized loops.
        </p>
      </div>

      {!challenge ? (
        /* Configuration Panel */
        <div className="max-w-xl mx-auto glass-panel p-6 sm:p-8 rounded-3xl shadow-xl space-y-6">
          <div className="text-center space-y-2">
            <div className="inline-flex p-3 bg-gradient-to-tr from-pink-500 to-rose-600 rounded-2xl text-white shadow-lg mb-2">
              <Terminal className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold font-sans">Setup Algorithmic Round</h2>
            <p className="text-xs text-zinc-400">Choose your targeted focus area and problem complexity difficulty.</p>
          </div>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-zinc-500 block">Algorithmic Topic Focus</label>
              <select
                id="coding-topic-picker"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full px-4 py-3 rounded-xl text-xs border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] backdrop-blur-md focus:outline-none focus:ring-1 focus:ring-indigo-500 text-zinc-900 dark:text-white"
              >
                {topics.map(t => (
                  <option key={t} value={t} className="dark:bg-slate-950">{t}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-zinc-500 block">Seniority Difficulty Bracket</label>
              <select
                id="coding-diff-picker"
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as any)}
                className="w-full px-4 py-3 rounded-xl text-xs border border-zinc-200/60 dark:border-white/10 bg-white/20 dark:bg-white/[0.03] backdrop-blur-md focus:outline-none focus:ring-1 focus:ring-indigo-500 text-zinc-900 dark:text-white"
              >
                <option value="Junior" className="dark:bg-slate-950">Junior (Booleans, easy linear arrays)</option>
                <option value="Mid-Level" className="dark:bg-slate-950">Mid-Level (Hashes, sliding window limits, tree traversing)</option>
                <option value="Senior" className="dark:bg-slate-950">Senior (Optimized DP, custom graphs, hard recursion)</option>
              </select>
            </div>

            <button
              id="btn-generate-challenge"
              type="submit"
              disabled={generating}
              className="w-full py-3.5 mt-4 rounded-xl bg-gradient-to-r from-pink-500 to-emerald-500 text-white font-semibold text-xs shadow-md transition hover:-translate-y-0.5 disabled:opacity-50 cursor-pointer flex items-center justify-center space-x-2"
            >
              {generating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Drafting challenge specs...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Enter Code Sandbox</span>
                </>
              )}
            </button>
          </form>
        </div>
      ) : (
        /* Code writing whiteboard area */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left panel: challenge definition */}
          <div className="lg:col-span-5 glass-panel p-6 rounded-3xl space-y-6">
            <div className="flex items-center justify-between border-b border-zinc-200/60 dark:border-white/10 pb-3">
              <div>
                <span className="text-[9px] font-bold text-pink-500 uppercase tracking-wider">{topic} ({difficulty})</span>
                <h3 className="text-base font-bold text-zinc-900 dark:text-white">{challenge.title}</h3>
              </div>
              <button
                id="btn-quit-challenge"
                onClick={() => {
                  if (window.confirm('Abandon this coding challenge? Progress will be lost.')) {
                    setChallenge(null);
                    setReview(null);
                  }
                }}
                className="text-[10px] text-zinc-500 hover:text-red-500 hover:underline"
              >
                Abandon
              </button>
            </div>

            {/* Description Statement */}
            <div className="space-y-3">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Problem Statement</span>
              <div className="text-xs text-zinc-600 dark:text-slate-300 leading-relaxed bg-white/10 dark:bg-white/[0.01] p-4 rounded-2xl border border-zinc-200/60 dark:border-white/5 backdrop-blur-sm">
                <p className="whitespace-pre-line">{challenge.description}</p>
              </div>
            </div>

            {/* Test cases panel */}
            {challenge.testCases && challenge.testCases.length > 0 && (
              <div className="space-y-3 pt-2">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Target Output Test Cases</span>
                <div className="space-y-2">
                  {challenge.testCases.map((tc, index) => (
                    <div 
                      key={index} 
                      className="p-3 bg-white/20 dark:bg-white/[0.02] rounded-xl border border-zinc-200/60 dark:border-white/10 font-mono text-[10px] flex items-center justify-between backdrop-blur-sm"
                    >
                      <div>
                        <span className="text-zinc-400">Input:</span> <span className="text-zinc-700 dark:text-zinc-300 font-semibold">{tc.input}</span>
                      </div>
                      <div>
                        <span className="text-zinc-400">Expected:</span> <span className="text-pink-500 font-semibold">{tc.output}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right panel: text editor workspace */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Editor visual workspace */}
            <div className="bg-zinc-950 rounded-3xl border border-zinc-800 p-4 shadow-2xl relative overflow-hidden">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3 mb-4">
                <div className="flex items-center space-x-1.5">
                  <span className="w-3 h-3 rounded-full bg-red-500" />
                  <span className="w-3 h-3 rounded-full bg-yellow-500" />
                  <span className="w-3 h-3 rounded-full bg-green-500" />
                  <span className="text-[10px] text-zinc-500 font-mono pl-2">whiteboard.{challenge.language === 'python' ? 'py' : 'js'}</span>
                </div>
                <span className="text-[9px] text-zinc-500 font-mono uppercase tracking-widest bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded-md">
                  {challenge.language || 'javascript'}
                </span>
              </div>

              {/* Code writing space */}
              <textarea
                id="coding-code-editor"
                rows={12}
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full bg-transparent font-mono text-xs text-zinc-200 focus:outline-none leading-relaxed resize-y min-h-[220px]"
                placeholder="// Write your optimized solution function here..."
              />

              <div className="border-t border-zinc-800 pt-3 mt-4 flex justify-between items-center text-[10px] text-zinc-500">
                <span>Press TAB for standard code spacing indentation.</span>
                <button
                  id="btn-submit-code-evaluation"
                  type="button"
                  onClick={handleEvaluate}
                  disabled={evaluating || !code.trim()}
                  className="flex items-center space-x-1.5 px-4 py-2 bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white rounded-lg font-bold transition disabled:opacity-50"
                >
                  {evaluating ? (
                    <>
                      <span className="animate-spin border-2 border-white/20 border-t-white rounded-full w-3.5 h-3.5 mr-1" />
                      <span>Reviewing complexity...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5 fill-current" />
                      <span>Evaluate Submission</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Review feedback panel */}
            {review && (
              <div className="glass-panel p-6 rounded-3xl space-y-5 animate-fadeIn">
                
                {/* Score and high level */}
                <div className="flex items-center justify-between border-b border-zinc-200/60 dark:border-white/10 pb-3">
                  <div className="flex items-center space-x-2">
                    <Award className="w-5 h-5 text-amber-500" />
                    <span className="text-sm font-extrabold text-zinc-800 dark:text-zinc-200">AI Code Review Matrix</span>
                  </div>
                  <span className="text-xs font-bold text-pink-500">
                    Grading Score: {review.score}/100
                  </span>
                </div>

                {/* Complexity & Correctness metrics */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
                  <div className="bg-white/25 dark:bg-white/[0.04] backdrop-blur-md p-3 rounded-xl border border-zinc-200/40 dark:border-white/10">
                    <span className="text-[10px] text-zinc-400 font-semibold block uppercase">Time Bounds</span>
                    <span className="text-sm font-mono font-extrabold text-indigo-500 mt-1 block">{review.complexityAnalysis.time}</span>
                  </div>
                  <div className="bg-white/25 dark:bg-white/[0.04] backdrop-blur-md p-3 rounded-xl border border-zinc-200/40 dark:border-white/10">
                    <span className="text-[10px] text-zinc-400 font-semibold block uppercase">Auxiliary Space</span>
                    <span className="text-sm font-mono font-extrabold text-purple-500 mt-1 block">{review.complexityAnalysis.space}</span>
                  </div>
                  <div className="bg-white/25 dark:bg-white/[0.04] backdrop-blur-md p-3 rounded-xl border border-zinc-200/40 dark:border-white/10">
                    <span className="text-[10px] text-zinc-400 font-semibold block uppercase">Hiring Grade</span>
                    <span className="text-sm font-extrabold text-emerald-500 mt-1 block">
                      {review.score >= 85 ? 'Strong Hire' : review.score >= 70 ? 'Borderline' : 'No Hire'}
                    </span>
                  </div>
                </div>

                {/* Feedback and optimizers */}
                <div className="space-y-4">
                  <div className="space-y-1">
                    <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider block">Correctness Review</span>
                    <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed bg-white/10 dark:bg-white/[0.02] backdrop-blur-sm p-3.5 rounded-xl border border-zinc-200/40 dark:border-white/5">
                      {review.correctness}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider block">Refactor & Optimization Suggestions</span>
                    <ul className="space-y-2">
                      {review.optimizationSuggestions.map((s, idx) => (
                        <li key={idx} className="text-xs text-zinc-600 dark:text-zinc-400 flex items-start space-x-2.5">
                          <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                          <span>{s}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Reset button */}
                <div className="flex justify-end pt-2 border-t border-zinc-200/60 dark:border-white/10">
                  <button
                    id="btn-reset-coding-dashboard"
                    onClick={() => {
                      setChallenge(null);
                      setReview(null);
                    }}
                    className="flex items-center space-x-1.5 px-5 py-2.5 rounded-xl bg-zinc-900 dark:bg-zinc-100 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 text-xs font-bold transition shadow-sm"
                  >
                    <span>Practice another algorithmic round</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>
            )}
          </div>

        </div>
      )}
    </div>
  );
}
