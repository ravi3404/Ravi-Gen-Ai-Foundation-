/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ThemeProvider, useTheme } from './components/ThemeContext.js';
import Navbar from './components/Navbar.js';
import LandingPage from './components/LandingPage.js';
import Auth from './components/Auth.js';
import Dashboard from './components/Dashboard.js';
import InterviewSetup from './components/InterviewSetup.js';
import AIInterviewer from './components/AIInterviewer.js';
import ReportView from './components/ReportView.js';
import ResumeAnalyzer from './components/ResumeAnalyzer.js';
import CodingRound from './components/CodingRound.js';
import Settings from './components/Settings.js';
import AdminPanel from './components/AdminPanel.js';
import { User, ExperienceLevel, InterviewType } from './types.js';

function MainAppContent() {
  const [user, setUser] = useState<{ id: string; name: string; email: string; isAdmin?: boolean } | null>(null);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('landing');
  const [activeInterviewId, setActiveInterviewId] = useState<string | null>(null);
  const [groundingResumeText, setGroundingResumeText] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(true);

  // Auto login from session token
  useEffect(() => {
    async function checkAuth() {
      const savedToken = localStorage.getItem('token');
      if (savedToken) {
        try {
          const res = await fetch('/api/auth/me', {
            headers: { 'Authorization': `Bearer ${savedToken}` }
          });
          const data = await res.json();
          if (res.ok && data.user) {
            setUser(data.user);
            setAuthToken(savedToken);
            setActiveTab('dashboard');
          } else {
            // Token expired or invalid, clear cache
            localStorage.removeItem('token');
          }
        } catch (err) {
          console.error('Session verify error:', err);
        }
      }
      setLoading(false);
    }
    checkAuth();
  }, []);

  const handleAuthSuccess = (u: any, token: string) => {
    setUser(u);
    setAuthToken(token);
    localStorage.setItem('token', token);
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setAuthToken(null);
    localStorage.removeItem('token');
    setActiveTab('landing');
  };

  const handleUpdateName = (newName: string) => {
    if (user) {
      const updated = { ...user, name: newName };
      setUser(updated);
    }
  };

  // Launch fresh setup round
  const handleStartNewInterview = () => {
    setGroundingResumeText(undefined);
    setActiveTab('setup');
  };

  // Triggers final start after setup parameters selected
  const handleStartInterviewAction = async (config: {
    jobRole: string;
    experienceLevel: ExperienceLevel;
    interviewType: InterviewType;
    duration: number;
    resumeText?: string;
  }) => {
    if (!authToken) return;

    // Get any client-configured OpenAI API key to inject as a custom request header
    const customKey = localStorage.getItem('openai_api_key') || '';
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    };
    if (customKey) {
      headers['x-openai-api-key'] = customKey;
    }

    const res = await fetch('/api/interviews', {
      method: 'POST',
      headers,
      body: JSON.stringify(config)
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to initialize session.');
    }

    setActiveInterviewId(data.interview.id);
    setActiveTab('interview');
  };

  // Launch grounding round from resume section
  const handleLaunchInterviewWithResume = (resumeText: string) => {
    setGroundingResumeText(resumeText);
    setActiveTab('setup');
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-zinc-50 dark:bg-zinc-950 text-zinc-500">
        <span className="animate-spin border-2 border-indigo-500 border-t-transparent rounded-full w-6 h-6 mb-4" />
        <span className="text-xs font-semibold">Resolving AI Coach Session...</span>
      </div>
    );
  }

  // Render the current view inside the page body
  const renderActiveView = () => {
    switch (activeTab) {
      case 'landing':
        return (
          <LandingPage 
            onGetStarted={() => user ? setActiveTab('dashboard') : setActiveTab('signup')}
            onLogin={() => user ? setActiveTab('dashboard') : setActiveTab('login')}
          />
        );
      case 'login':
        return (
          <Auth 
            initialMode="login" 
            onAuthSuccess={handleAuthSuccess}
            onSwitchMode={(mode) => setActiveTab(mode)}
          />
        );
      case 'signup':
        return (
          <Auth 
            initialMode="signup" 
            onAuthSuccess={handleAuthSuccess}
            onSwitchMode={(mode) => setActiveTab(mode)}
          />
        );
      case 'dashboard':
        return user && authToken ? (
          <Dashboard 
            user={user}
            authToken={authToken}
            onStartNewInterview={handleStartNewInterview}
            onViewReport={(id) => {
              setActiveInterviewId(id);
              setActiveTab('report');
            }}
            onResumeTab={() => setActiveTab('resume')}
            onCodingTab={() => setActiveTab('coding')}
          />
        ) : null;
      case 'setup':
        return authToken ? (
          <InterviewSetup 
            authToken={authToken}
            onStartInterview={handleStartInterviewAction}
          />
        ) : null;
      case 'interview':
        return activeInterviewId && authToken ? (
          <AIInterviewer 
            interviewId={activeInterviewId}
            authToken={authToken}
            onInterviewComplete={(id) => {
              setActiveInterviewId(id);
              setActiveTab('report');
            }}
            onExit={() => setActiveTab('dashboard')}
          />
        ) : null;
      case 'report':
        return activeInterviewId && authToken ? (
          <ReportView 
            interviewId={activeInterviewId}
            authToken={authToken}
            onBack={() => setActiveTab('dashboard')}
          />
        ) : null;
      case 'resume':
        return authToken ? (
          <ResumeAnalyzer 
            authToken={authToken}
            onLaunchInterviewWithResume={handleLaunchInterviewWithResume}
          />
        ) : null;
      case 'coding':
        return authToken ? (
          <CodingRound 
            authToken={authToken}
          />
        ) : null;
      case 'settings':
        return user ? (
          <Settings 
            user={user}
            onUpdateName={handleUpdateName}
          />
        ) : null;
      case 'admin':
        return user?.isAdmin && authToken ? (
          <AdminPanel 
            authToken={authToken}
          />
        ) : null;
      default:
        return <div className="text-center py-12">View selector exception. Invalid route parameter.</div>;
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-[#020617] text-zinc-900 dark:text-slate-100 transition-colors duration-300 relative overflow-hidden flex flex-col">
      {/* Ambient Background Gradients from "Frosted Glass" design */}
      <div className="absolute top-[-10%] left-[-10%] w-[45%] h-[45%] bg-indigo-600/10 dark:bg-indigo-600/25 blur-[120px] rounded-full pointer-events-none z-0" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[45%] h-[45%] bg-violet-600/10 dark:bg-violet-600/25 blur-[120px] rounded-full pointer-events-none z-0" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60%] h-[20%] bg-emerald-500/5 dark:bg-emerald-500/10 blur-[100px] rotate-12 pointer-events-none z-0" />

      <Navbar 
        user={user} 
        onLogout={handleLogout} 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
      />
      
      <main className="animate-fadeIn flex-1 relative z-10">
        {renderActiveView()}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <MainAppContent />
    </ThemeProvider>
  );
}
