import fs from 'fs';
import path from 'path';
import { User, Interview, Resume } from './types.js';

const DB_DIR = path.join(process.cwd(), '.data');
const DB_FILE = path.join(DB_DIR, 'db.json');

interface Schema {
  users: User[];
  interviews: Interview[];
  resumes: Resume[];
}

function initializeDb(): Schema {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  if (fs.existsSync(DB_FILE)) {
    try {
      const data = fs.readFileSync(DB_FILE, 'utf8');
      return JSON.parse(data);
    } catch (e) {
      console.error('Error reading DB, resetting', e);
    }
  }

  const initial: Schema = {
    users: [],
    interviews: [],
    resumes: [],
  };
  fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf8');
  return initial;
}

export class Database {
  private static schema: Schema = initializeDb();

  private static save() {
    fs.writeFileSync(DB_FILE, JSON.stringify(this.schema, null, 2), 'utf8');
  }

  // User methods
  static getUsers(): User[] {
    return this.schema.users;
  }

  static getUserByEmail(email: string): User | undefined {
    return this.schema.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  static getUserById(id: string): User | undefined {
    return this.schema.users.find((u) => u.id === id);
  }

  static createUser(user: User): User {
    this.schema.users.push(user);
    this.save();
    return user;
  }

  static updateUser(id: string, updates: Partial<User>): User | undefined {
    const user = this.getUserById(id);
    if (user) {
      Object.assign(user, updates);
      this.save();
    }
    return user;
  }

  // Interview methods
  static getInterviews(): Interview[] {
    return this.schema.interviews;
  }

  static getInterviewsByUserId(userId: string): Interview[] {
    return this.schema.interviews.filter((i) => i.userId === userId);
  }

  static getInterviewById(id: string): Interview | undefined {
    return this.schema.interviews.find((i) => i.id === id);
  }

  static createInterview(interview: Interview): Interview {
    this.schema.interviews.push(interview);
    this.save();
    return interview;
  }

  static updateInterview(id: string, updates: Partial<Interview>): Interview | undefined {
    const interview = this.getInterviewById(id);
    if (interview) {
      Object.assign(interview, updates);
      this.save();
    }
    return interview;
  }

  static deleteInterview(id: string): boolean {
    const index = this.schema.interviews.findIndex((i) => i.id === id);
    if (index !== -1) {
      this.schema.interviews.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }

  // Resume methods
  static getResumesByUserId(userId: string): Resume[] {
    return this.schema.resumes.filter((r) => r.userId === userId);
  }

  static getResumeById(id: string): Resume | undefined {
    return this.schema.resumes.find((r) => r.id === id);
  }

  static createResume(resume: Resume): Resume {
    this.schema.resumes.push(resume);
    this.save();
    return resume;
  }

  static deleteResume(id: string): boolean {
    const index = this.schema.resumes.findIndex((r) => r.id === id);
    if (index !== -1) {
      this.schema.resumes.splice(index, 1);
      this.save();
      return true;
    }
    return false;
  }
}
