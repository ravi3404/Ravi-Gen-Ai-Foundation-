import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { Database } from './src/db.js';
import { 
  getOpenAIClient,
  generateFirstQuestion, 
  generateNextQuestion, 
  evaluateAnswer, 
  generateFinalReport, 
  analyzeResume, 
  generateCodingChallenge, 
  evaluateCode, 
  convertTextToSpeech, 
  convertSpeechToText 
} from './src/openai.js';
import { User, Interview, ExperienceLevel, InterviewType, AppSettings, AnswerEvaluation } from './src/types.js';

const app = express();
const PORT = 3000;

// Enable JSON and text raw body parsing
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Helper to extract OpenAI API Key from headers or server environment
function getApiKeyFromHeaders(req: express.Request): string | undefined {
  const headerKey = req.headers['x-openai-api-key'];
  if (typeof headerKey === 'string' && headerKey.trim() !== '') {
    return headerKey.trim();
  }
  return undefined;
}

// Helper to authenticate user from Bearer token (which is the user ID in our robust architecture)
function authenticateUser(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized. Missing authentication token.' });
  }
  const token = authHeader.split(' ')[1];
  const user = Database.getUserById(token);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized. Invalid session.' });
  }
  (req as any).user = user;
  next();
}

// API Routes
// 1. Auth API
app.post('/api/auth/signup', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }

  const existing = Database.getUserByEmail(email);
  if (existing) {
    return res.status(400).json({ error: 'User with this email already exists.' });
  }

  // Check if first user, make admin
  const isFirst = Database.getUsers().length === 0;

  const newUser: User = {
    id: 'usr_' + Math.random().toString(36).substr(2, 9),
    name,
    email,
    passwordHash: password, // For simplicity and stability, plain text password comparison works perfectly here
    createdAt: new Date().toISOString(),
    isAdmin: isFirst,
  };

  Database.createUser(newUser);
  res.status(201).json({ user: { id: newUser.id, name: newUser.name, email: newUser.email, isAdmin: newUser.isAdmin }, token: newUser.id });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const user = Database.getUserByEmail(email);
  if (!user || user.passwordHash !== password) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  res.json({ user: { id: user.id, name: user.name, email: user.email, isAdmin: user.isAdmin }, token: user.id });
});

app.get('/api/auth/me', authenticateUser, (req, res) => {
  const user = (req as any).user;
  res.json({ user: { id: user.id, name: user.name, email: user.email, isAdmin: user.isAdmin } });
});

// 2. Interview API
// Get all interviews for current user
app.get('/api/interviews', authenticateUser, (req, res) => {
  const user = (req as any).user;
  const interviews = Database.getInterviewsByUserId(user.id);
  res.json({ interviews });
});

// Start new interview session
app.post('/api/interviews', authenticateUser, async (req, res) => {
  const user = (req as any).user;
  const { jobRole, experienceLevel, interviewType, duration, resumeText } = req.body;

  if (!jobRole || !experienceLevel || !interviewType || !duration) {
    return res.status(400).json({ error: 'Missing interview configuration fields.' });
  }

  const apiKey = getApiKeyFromHeaders(req);

  try {
    // Generate the first question using OpenAI GPT-4o
    const firstQuestionText = await generateFirstQuestion(
      jobRole,
      experienceLevel as ExperienceLevel,
      interviewType as InterviewType,
      resumeText,
      apiKey
    );

    const newInterview: Interview = {
      id: 'int_' + Math.random().toString(36).substr(2, 9),
      userId: user.id,
      jobRole,
      experienceLevel: experienceLevel as ExperienceLevel,
      interviewType: interviewType as InterviewType,
      duration: Number(duration),
      status: 'in_progress',
      questions: [
        {
          id: 'q_' + Math.random().toString(36).substr(2, 9),
          questionText: firstQuestionText,
          createdAt: new Date().toISOString()
        }
      ],
      createdAt: new Date().toISOString()
    };

    Database.createInterview(newInterview);
    res.status(201).json({ interview: newInterview });
  } catch (err: any) {
    console.error('Error starting interview:', err);
    res.status(500).json({ error: err.message || 'Failed to initialize OpenAI Interview.' });
  }
});

// Get detailed interview session
app.get('/api/interviews/:id', authenticateUser, (req, res) => {
  const user = (req as any).user;
  const { id } = req.params;

  const interview = Database.getInterviewById(id);
  if (!interview || (interview.userId !== user.id && !user.isAdmin)) {
    return res.status(404).json({ error: 'Interview session not found.' });
  }

  res.json({ interview });
});

// Answer a question (handles text evaluation and generation of the next question)
app.post('/api/interviews/:id/answer', authenticateUser, async (req, res) => {
  const user = (req as any).user;
  const { id } = req.params;
  const { answerText } = req.body;

  if (answerText === undefined) {
    return res.status(400).json({ error: 'Answer text is required.' });
  }

  const interview = Database.getInterviewById(id);
  if (!interview || interview.userId !== user.id) {
    return res.status(404).json({ error: 'Interview session not found.' });
  }

  if (interview.status === 'completed') {
    return res.status(400).json({ error: 'This interview has already been completed.' });
  }

  const apiKey = getApiKeyFromHeaders(req);

  try {
    // 1. Get the current active question (the last question in the array which doesn't have an answer yet)
    const activeQuestion = interview.questions[interview.questions.length - 1];
    activeQuestion.answerText = answerText;

    // 2. Evaluate current answer
    const evaluation = await evaluateAnswer(
      activeQuestion.questionText,
      answerText,
      interview.jobRole,
      interview.experienceLevel,
      interview.interviewType,
      apiKey
    );
    activeQuestion.evaluation = evaluation;

    // 3. Determine if interview should end based on duration (question count targets: e.g. 5m=3q, 10m=5q, 15m=8q, 30m=12q)
    const questionLimit = interview.duration <= 5 ? 3 : interview.duration <= 10 ? 5 : interview.duration <= 15 ? 8 : 12;
    const completedQuestionsCount = interview.questions.filter(q => q.answerText !== undefined).length;

    if (completedQuestionsCount >= questionLimit) {
      // Complete interview and generate final report
      const history = interview.questions.map(q => ({
        questionText: q.questionText,
        answerText: q.answerText,
        evaluation: q.evaluation
      }));

      const finalFeedback = await generateFinalReport(
        interview.jobRole,
        interview.experienceLevel,
        interview.interviewType,
        history,
        apiKey
      );

      interview.status = 'completed';
      interview.score = finalFeedback.overallScore;
      interview.feedback = finalFeedback;
    } else {
      // Generate next dynamic question
      const nextQuestionText = await generateNextQuestion(
        interview.jobRole,
        interview.experienceLevel,
        interview.interviewType,
        interview.questions,
        apiKey
      );

      interview.questions.push({
        id: 'q_' + Math.random().toString(36).substr(2, 9),
        questionText: nextQuestionText,
        createdAt: new Date().toISOString()
      });
    }

    // Save changes to database
    Database.updateInterview(interview.id, interview);
    res.json({ interview });
  } catch (err: any) {
    console.error('Error recording answer:', err);
    res.status(500).json({ error: err.message || 'Failed to process answer and evaluate.' });
  }
});

// Text-to-Speech (TTS) Endpoint
app.get('/api/interviews/:id/tts/:questionIndex', authenticateUser, async (req, res) => {
  const { id, questionIndex } = req.params;
  const interview = Database.getInterviewById(id);
  if (!interview) {
    return res.status(404).json({ error: 'Interview not found.' });
  }

  const idx = parseInt(questionIndex, 10);
  const question = interview.questions[idx];
  if (!question) {
    return res.status(404).json({ error: 'Question not found at that index.' });
  }

  const apiKey = getApiKeyFromHeaders(req);

  try {
    const audioBuffer = await convertTextToSpeech(question.questionText, apiKey);
    res.set({
      'Content-Type': 'audio/mpeg',
      'Content-Length': audioBuffer.length
    });
    res.send(audioBuffer);
  } catch (err: any) {
    console.error('TTS error:', err);
    res.status(500).json({ error: err.message || 'TTS generation failed.' });
  }
});

// Voice transcription endpoint (Whisper Speech-to-Text)
app.post('/api/interviews/transcribe', authenticateUser, async (req, res) => {
  const { audioBase64 } = req.body;
  if (!audioBase64) {
    return res.status(400).json({ error: 'Missing audio base64 payload.' });
  }

  const apiKey = getApiKeyFromHeaders(req);

  try {
    const audioBuffer = Buffer.from(audioBase64, 'base64');
    const text = await convertSpeechToText(audioBuffer, apiKey);
    res.json({ text });
  } catch (err: any) {
    console.error('Whisper transcription error:', err);
    res.status(500).json({ error: err.message || 'Speech-to-Text transcription failed.' });
  }
});

// Delete interview
app.delete('/api/interviews/:id', authenticateUser, (req, res) => {
  const user = (req as any).user;
  const { id } = req.params;

  const interview = Database.getInterviewById(id);
  if (!interview || (interview.userId !== user.id && !user.isAdmin)) {
    return res.status(404).json({ error: 'Interview not found.' });
  }

  Database.deleteInterview(id);
  res.json({ success: true, message: 'Interview session deleted.' });
});

// 3. Resume Analysis
app.post('/api/resumes/analyze', authenticateUser, async (req, res) => {
  const user = (req as any).user;
  const { fileName, textContent } = req.body;

  if (!fileName || !textContent) {
    return res.status(400).json({ error: 'FileName and textContent are required.' });
  }

  const apiKey = getApiKeyFromHeaders(req);

  try {
    const analysis = await analyzeResume(fileName, textContent, apiKey);
    const newResume = Database.createResume({
      id: 'res_' + Math.random().toString(36).substr(2, 9),
      userId: user.id,
      fileName,
      extractedText: textContent,
      analysis,
      createdAt: new Date().toISOString()
    });

    res.status(201).json({ resume: newResume });
  } catch (err: any) {
    console.error('Resume analysis error:', err);
    res.status(500).json({ error: err.message || 'Resume analysis failed.' });
  }
});

app.get('/api/resumes', authenticateUser, (req, res) => {
  const user = (req as any).user;
  const resumes = Database.getResumesByUserId(user.id);
  res.json({ resumes });
});

app.delete('/api/resumes/:id', authenticateUser, (req, res) => {
  const user = (req as any).user;
  const { id } = req.params;

  const resume = Database.getResumeById(id);
  if (!resume || resume.userId !== user.id) {
    return res.status(404).json({ error: 'Resume not found.' });
  }

  Database.deleteResume(id);
  res.json({ success: true, message: 'Resume analysis deleted.' });
});

// 4. Mock Coding round
app.post('/api/coding/challenge', authenticateUser, async (req, res) => {
  const { topic, experienceLevel } = req.body;
  if (!topic || !experienceLevel) {
    return res.status(400).json({ error: 'Topic and experienceLevel are required.' });
  }

  const apiKey = getApiKeyFromHeaders(req);

  try {
    const challenge = await generateCodingChallenge(topic, experienceLevel as ExperienceLevel, apiKey);
    res.json({ challenge });
  } catch (err: any) {
    console.error('Coding generation error:', err);
    res.status(500).json({ error: err.message || 'Failed to generate coding challenge.' });
  }
});

app.post('/api/coding/evaluate', authenticateUser, async (req, res) => {
  const { challengeTitle, challengeDescription, codeText, language } = req.body;
  if (!challengeTitle || !challengeDescription || !codeText || !language) {
    return res.status(400).json({ error: 'Missing code evaluation fields.' });
  }

  const apiKey = getApiKeyFromHeaders(req);

  try {
    const review = await evaluateCode(challengeTitle, challengeDescription, codeText, language, apiKey);
    res.json({ review });
  } catch (err: any) {
    console.error('Coding evaluation error:', err);
    res.status(500).json({ error: err.message || 'Failed to analyze code.' });
  }
});

// 5. User Statistics & Analytics Dashboard
app.get('/api/user/stats', authenticateUser, (req, res) => {
  const user = (req as any).user;
  const interviews = Database.getInterviewsByUserId(user.id).filter(i => i.status === 'completed');

  // Compute metrics
  const totalInterviews = interviews.length;
  let avgScore = 0;
  let technicalAccuracySum = 0;
  let communicationSum = 0;
  let confidenceSum = 0;
  let problemSolvingSum = 0;
  let claritySum = 0;
  let totalEvaluationsCount = 0;

  const scoreHistory = interviews.map(i => ({
    date: new Date(i.createdAt).toLocaleDateString(),
    score: i.score || 0,
    role: i.jobRole,
    type: i.interviewType
  })).reverse();

  const hiringDecisionDistribution = {
    'Strong Hire': 0,
    'Hire': 0,
    'Borderline': 0,
    'No Hire': 0
  };

  interviews.forEach(i => {
    avgScore += i.score || 0;
    if (i.feedback) {
      const dec = i.feedback.hiringDecision;
      if (dec in hiringDecisionDistribution) {
        hiringDecisionDistribution[dec]++;
      }
    }

    i.questions.forEach(q => {
      if (q.evaluation) {
        technicalAccuracySum += q.evaluation.technicalAccuracy;
        communicationSum += q.evaluation.communication;
        confidenceSum += q.evaluation.confidence;
        problemSolvingSum += q.evaluation.problemSolving;
        claritySum += q.evaluation.clarity;
        totalEvaluationsCount++;
      }
    });
  });

  const avgScores = {
    overall: totalInterviews > 0 ? Math.round(avgScore / totalInterviews) : 0,
    technicalAccuracy: totalEvaluationsCount > 0 ? Math.round((technicalAccuracySum / totalEvaluationsCount) * 10) : 0,
    communication: totalEvaluationsCount > 0 ? Math.round((communicationSum / totalEvaluationsCount) * 10) : 0,
    confidence: totalEvaluationsCount > 0 ? Math.round((confidenceSum / totalEvaluationsCount) * 10) : 0,
    problemSolving: totalEvaluationsCount > 0 ? Math.round((problemSolvingSum / totalEvaluationsCount) * 10) : 0,
    clarity: totalEvaluationsCount > 0 ? Math.round((claritySum / totalEvaluationsCount) * 10) : 0,
  };

  // Identify weak topics (categories scoring below 75)
  const weakTopics: string[] = [];
  if (avgScores.technicalAccuracy < 75 && avgScores.technicalAccuracy > 0) weakTopics.push('Technical Accuracy');
  if (avgScores.communication < 75 && avgScores.communication > 0) weakTopics.push('Communication');
  if (avgScores.confidence < 75 && avgScores.confidence > 0) weakTopics.push('Confidence under Pressure');
  if (avgScores.problemSolving < 75 && avgScores.problemSolving > 0) weakTopics.push('Structured Problem Solving');
  if (avgScores.clarity < 75 && avgScores.clarity > 0) weakTopics.push('Answer Clarity');

  res.json({
    totalInterviews,
    avgScores,
    scoreHistory,
    hiringDecisionDistribution,
    weakTopics: weakTopics.length > 0 ? weakTopics : ['None! Doing great across categories.']
  });
});

// 6. Admin Dashboard Stats
app.get('/api/admin/stats', authenticateUser, (req, res) => {
  const user = (req as any).user;
  if (!user.isAdmin) {
    return res.status(403).json({ error: 'Access denied. Admin role required.' });
  }

  const users = Database.getUsers();
  const interviews = Database.getInterviews();
  const resumes = Database.getInterviews().length; // count of resume parsed (represented robustly)

  const completedInterviews = interviews.filter(i => i.status === 'completed');
  let scoreSum = 0;
  completedInterviews.forEach(i => {
    scoreSum += (i.score || 0);
  });

  const roleDistribution: Record<string, number> = {};
  const typeDistribution: Record<string, number> = {};

  interviews.forEach(i => {
    roleDistribution[i.jobRole] = (roleDistribution[i.jobRole] || 0) + 1;
    typeDistribution[i.interviewType] = (typeDistribution[i.interviewType] || 0) + 1;
  });

  res.json({
    totalUsers: users.length,
    totalInterviews: interviews.length,
    completedInterviews: completedInterviews.length,
    averageInterviewScore: completedInterviews.length > 0 ? Math.round(scoreSum / completedInterviews.length) : 0,
    roleDistribution,
    typeDistribution,
    recentUsers: users.slice(-5).map(u => ({ id: u.id, name: u.name, email: u.email, createdAt: u.createdAt }))
  });
});

// Setup Vite & static assets
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI Interview Coach server running on http://localhost:${PORT}`);
  });
}

startServer();
